#include <stdio.h>
int main()
{

	int num;
	scanf("%d", &num);
	int first_digit = num / 10 / 10;
	int last_digit = num % 10;
	int middle_digit = (num / 10) % 10;
	
	if ((num % 7 == 0) || (first_digit == 7) || (last_digit == 7) || (middle_digit == 7))
       printf("Boom");
	
	return 0;
}


	