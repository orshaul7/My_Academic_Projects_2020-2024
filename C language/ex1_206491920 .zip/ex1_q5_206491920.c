#include <stdio.h>
int main()
{
	char tav;
	scanf("%c", &tav);
	if (((int)tav >= 0 && (int)tav <= 64) || ((int)tav >= 91 && (int)tav <= 96) || ((int)tav >= 123 && (int)tav <= 127))
		printf("Invalid imput!");
	else
	{
		if ((int)tav >= 97 && (int)tav <= 122)
		{
			tav = (int)tav - 32;
			printf("%c", tav);
		}
		else 
		{
			tav = (int)tav + 32;
			printf("%c", tav);
		}
	}

	return 0;
}