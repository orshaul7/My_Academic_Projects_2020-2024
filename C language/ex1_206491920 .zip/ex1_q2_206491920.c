#include <stdio.h>
int main()
{

	int n, i, factorial=1;
	
	scanf("%d", &n);
	
	
	if (n < 0 || n > 10)
	{
		printf("Invalid input!");
	}
	else 
	{
		for (i = n; i>0; i--)
		{
			factorial = factorial * i;
	    }
		printf("%d", factorial);
	}

	return 0;
}

	
	






