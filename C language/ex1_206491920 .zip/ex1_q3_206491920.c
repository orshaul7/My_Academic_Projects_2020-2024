#include <stdio.h>
int main()
{
 int math, literature, eng, max, min; float avg;

 printf("please enter your grades in Mathemaics, Literature, English in this order\n");
 scanf("%d, %d, %d", &math, &literature, &eng);
 
 if (math > literature)
 {
	 max = math;
	 min = literature;
 }
 else
 {
	 max = literature;
	 min = math;
 }
 if (eng > max)
	 max = eng;

 if (eng < min)
	 min = eng;

 

 avg = (math + literature + eng) / 3;

 if (avg > 95)
	 printf("\"great\"\t");
 if (avg > 85 && avg <= 95)
	 printf("\"very good\"\t");
 if (avg > 70 && avg <= 85)
	 printf("\"good\"\t");


 if (0>math || math > 100 || 0 > literature|| literature > 100 || 0 > eng|| eng > 100)
	 printf("Invalid inputs!");
	 
 else
	 printf("%d,%d",min, max);
	
 return 0;

}



