% Define the system parameters
tau = 0.1; % Time constant
G = tf(1, [tau 1]); % Transfer function G(s) = 1 / (0.1s + 1)

% Define the proportional gain
Kp = 10;

% Closed-loop transfer function
T = feedback(Kp * G, 1);

% Plot the step response of the closed-loop system
figure;
step(T);
hold on;

% Calculate the theoretical steady-state value
ess = 1 / (1 + Kp); % Steady-state error
theoretical_ss_value = 1 - ess; % For a unit step input

% Add the theoretical steady-state value to the plot
yline(theoretical_ss_value, 'r--', 'Theoretical SS Value', 'LabelHorizontalAlignment', 'left');

% Plot customization
title('Closed-Loop Step Response with Kp = 10');
xlabel('Time');
ylabel('Amplitude');
grid on;
legend('Closed-Loop Response', 'Theoretical SS Value');

hold off;
