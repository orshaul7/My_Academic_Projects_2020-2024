% Define the system parameters
tau = 0.1; % Time constant
K = 1;     % Steady-state gain

% Calculate the cutoff frequency
omega_b = 1 / tau;

% Create the transfer function G(s) = 1 / (0.1s + 1)
G = tf(K, [tau 1]);

% Define the time vector for simulation
t = 0:0.01:10; % 0 to 10 seconds with a step of 0.01 seconds

% Define the sinusoidal input at the cutoff frequency
input_amplitude = 1; % Amplitude of the sinusoidal input
input = input_amplitude * sin(omega_b * t);

% Simulate the system response using lsim
[y, t_out] = lsim(G, input, t);

% Plot the system response at the cutoff frequency
figure;
plot(t_out, input, 'b--', 'DisplayName', 'Input Signal');
hold on;
plot(t_out, y, 'r', 'DisplayName', sprintf('Output at \\omega_b = %.2f rad/s', omega_b));
legend;
title(sprintf('System Response at Cutoff Frequency \\omega_b = %.2f rad/s', omega_b));
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;
hold off;
