% Define the system parameters
tau = 0.1; % Time constant of the plant
G = tf(1, [tau 1]); % Transfer function G(s) = 1 / (0.1s + 1)

% Define the PI controller parameters
Kp = 1;
Ki = 1;
C = tf([Kp Ki], [1 0]); % PI controller C(s) = Kp + Ki/s

% Open-loop transfer function
L = series(C, G);

% Closed-loop transfer function
T = feedback(L, 1);

% Calculate the step response of the closed-loop system
[response, time] = step(T);

% Calculate the theoretical steady-state value
% For a PI controller, the steady-state error should be zero for a step input
theoretical_ss_value = 1; % Because the steady-state error ess = 0

% Calculate the actual steady-state value
actual_ss_value = response(end); % Steady-state value from step response

% Calculate the delta between actual and theoretical steady-state values
delta_ss = abs(actual_ss_value - theoretical_ss_value);

% Plot the step response of the closed-loop system
figure;
plot(time, response, 'b', 'LineWidth', 1.5);
hold on;


% Plot customization
title('Closed-Loop Step Response with PI Controller (Kp = 1, Ki = 1)');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;


hold off;
