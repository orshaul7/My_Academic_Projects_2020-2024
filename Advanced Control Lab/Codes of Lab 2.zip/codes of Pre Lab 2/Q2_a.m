% Define the system parameters
tau = 0.1; % Time constant
K = 1;     % Steady-state gain

% Create the transfer function G(s) = 1 / (0.1s + 1)
G = tf(K, [tau 1]);

% Define the frequencies for the sinusoidal inputs (in rad/s)
frequencies = [1, 5, 10, 20, 50];

% Time vector for simulation
t = 0:0.01:10; % 0 to 10 seconds with a step of 0.01 seconds

% Initialize arrays to store results
gains = zeros(1, length(frequencies));
input_amplitude = 1; % Amplitude of the sinusoidal input

figure;
hold on;

% Define colors for the plots
colors = ['b', 'r', 'g', 'm', 'k'];

for i = 1:length(frequencies)
    % Define the sinusoidal input
    f = frequencies(i);
    input = input_amplitude * sin(f * t);
    
    % Simulate the system response using lsim
    [y, t_out] = lsim(G, input, t);
    
    % Calculate the gain change (ratio of output amplitude to input amplitude)
    output_amplitude = max(y) - min(y); % Peak-to-peak amplitude of the output signal
    gains(i) = output_amplitude / (2 * input_amplitude); % Amplitude gain
    
    % Plot the system response
    plot(t_out, y, colors(i), 'DisplayName', sprintf('Output at %d rad/s', f));
end

% Plot the input signal for reference
input_signal = input_amplitude * sin(frequencies(1) * t);
plot(t, input_signal, 'k--', 'DisplayName', 'Input Signal');

% Add legend and labels
legend;
title('System Response to Sinusoidal Inputs at Various Frequencies');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;
hold off;

% Plot the gain change as a function of frequency
figure;
semilogx(frequencies, gains, 'o-');
grid on;
title('Gain Change as a Function of Frequency');
xlabel('Frequency (rad/s)');
ylabel('Gain');
