% Define the system parameters
tau = 0.1; % Time constant
G = tf(1, [tau 1]); % Transfer function G(s) = 1 / (0.1s + 1)

% Define the PI controller parameters based on calculations
K_p = 1.1;
K_i = 22.5;

% Define the PI controller transfer function
C = tf([K_p K_i], [1 0]);

% Closed-loop transfer function
T = feedback(C * G, 1);

% Simulate the step response of the closed-loop system
figure;
step(T);
title('Closed-Loop Step Response with PI Controller');
xlabel('Time');
ylabel('Amplitude');
grid on;

% Display the step response characteristics
stepinfo(T)
