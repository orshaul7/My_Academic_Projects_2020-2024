% Define the system parameters
tau = 0.1; % Time constant
K = 1;     % Steady-state gain

% Create the transfer function G(s) = K / (tau*s + 1)
G = tf(K, [tau 1]);

% Plot the step response
figure;
step(G);
hold on;

% Calculate and mark the time constant on the plot
[y, t] = step(G);
tau_index = find(t >= tau, 1); % Find the index corresponding to the time constant
plot(t(tau_index), y(tau_index), 'ro', 'MarkerFaceColor', 'r'); % Mark the time constant

% Annotate the plot
text(t(tau_index), y(tau_index), sprintf('\\leftarrow \\tau = %.2f', tau), 'VerticalAlignment', 'bottom');

% Steady-state gain
steady_state_gain = K;
text(t(end), steady_state_gain, sprintf('K = %.2f \\rightarrow', steady_state_gain), 'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom');

% Add grid and labels
grid on;
title('Step Response of First Order System');
xlabel('Time');
ylabel('Amplitude');
legend('Step Response', '\tau = Time Constant');

hold off;
