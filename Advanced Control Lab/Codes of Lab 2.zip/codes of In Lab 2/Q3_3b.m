% Assuming ScopeData is already loaded in the workspace

% Define the transfer function T (example)
% Replace 'num' and 'den' with your actual system parameters
num = [1]; % Numerator of the transfer function
den = [1 2 1]; % Denominator of the transfer function
T = tf(num, den);

% Extract time and output data
time = ScopeData.time;
output = ScopeData.signals.values(:,2);

% Plot the recorded data
figure;
plot(time, output, 'b');
hold on;

% Simulate the step response
simulated_step_response = step(T, time) * 7; % Multiply by 7 for the step from 0 to 7 volts
plot(time + 1, simulated_step_response, 'r--');

% Add labels, title, and legend
xlabel('Time (seconds)');
ylabel('Response');
title('Step Response Comparison');
legend('Recorded Response', 'Simulated Response');
grid on;

% Set x-axis range from -1 to 9
xlim([-1 9]);

% Save the ScopeData structure to a .mat file
save('record_3_3.mat', 'ScopeData');
