% Generate plots from recordings and simulated transfer function
s = tf('s');
G = 2.5 / (0.1 * s + 1);
LPF = 1 / (0.05 * s + 1);

% Extract time, input, and output data
time = ScopeData.time;
input = ScopeData.signals.values(:,1);
output = ScopeData.signals.values(:,2);

% Create figure for the plots
figure(1)

% Plot recorded input data
plot(time, input, 'b', 'DisplayName', 'Recorded Input');
hold on

% Plot recorded output data
plot(time, output, 'r.', 'DisplayName', 'Recorded Output');

% Simulate and plot the step response for G/(1+G)
[y1, t1] = lsim(G / (1 + G), input, time);
plot(t1, y1, 'g', 'DisplayName', 'Simulated G/(1+G)');

% Simulate and plot the step response for G*LPF/(1+G*LPF)
[y2, t2] = lsim(G * LPF / (1 + G * LPF), input, time);
plot(t2, y2, 'k', 'DisplayName', 'Simulated G*LPF/(1+G*LPF)');

% Add grid, labels, title, and legend
grid on;
xlabel('Time (seconds)');
ylabel('Response [rad/sec]');
title('Step Response Comparison');
legend;
xlim([-1 9]); % Set x-axis range from -1 to 9

% Save the ScopeData structure to a .mat file
save('record_Q_3_5_1.mat', 'ScopeData');
