% Assuming ScopeData is already loaded in the workspace

% Extract time, input, and output data
time = ScopeData.time;
input = ScopeData.signals.values(:,1);
output = ScopeData.signals.values(:,2);

% Plot the data
figure;
plot(time, input, 'r', time, output, 'b');
xlabel('Time [sec]');
ylabel('Amplitude');
legend('Input voltage', 'Measured angular velocity');
title('Input Voltage [V] and measured angular velocity [rad/sec] as a function of time');
grid on;


% Save the ScopeData structure to a .mat file
save('record_3_1.mat', 'ScopeData');
