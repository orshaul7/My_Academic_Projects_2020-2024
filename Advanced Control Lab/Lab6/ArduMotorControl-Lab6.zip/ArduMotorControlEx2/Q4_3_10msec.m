% Define parameters
gain = 0.25;
period = 5; % seconds
control_periods = [0.01, 0.1]; % seconds

% Define time vectors
t1 = 0:control_periods(1):period;
t2 = 0:control_periods(2):period;

% Generate ramp response
MotorCMD1 = gain * t1;
MotorCMD2 = gain * t2;

% Simulate measured RPM (assuming perfect system for simplicity)
RPMdt1 = MotorCMD1;
RPMdt2 = MotorCMD2;

RPMPulses1 = MotorCMD1;
RPMPulses2 = MotorCMD2;

% Combine data into one matrix
data1 = [t1', MotorCMD1', RPMdt1', RPMPulses1'];
data2 = [t2', MotorCMD2', RPMdt2', RPMPulses2'];

% Identify unique motor commands
unique_cmds = unique([MotorCMD1, MotorCMD2]);

% Separate data for the two control intervals
interval1_data = data1;
interval2_data = data2;

% Plot RPMPulses for the two control intervals
figure;
plot(interval1_data(:, 1), interval1_data(:, 4), 'b-o', 'DisplayName', '10ms Control Interval');
hold on;
plot(interval2_data(:, 1), interval2_data(:, 4), 'r-o', 'DisplayName', '100ms Control Interval');
xlabel('Time [s]');
ylabel('RPMPulses');
title('RPMPulses at Two Measured Control Intervals');
legend;
grid on;
hold off;

% Calculate the difference between RPMPulses and RPMdt
diff_interval1 = interval1_data(:, 4) - interval1_data(:, 3);
diff_interval2 = interval2_data(:, 4) - interval2_data(:, 3);

% Plot the difference between RPMPulses and RPMdt as a function of motor command
figure;
plot(interval1_data(:, 1), diff_interval1, 'b-o', 'DisplayName', '10ms Control Interval');
hold on;
plot(interval2_data(:, 1), diff_interval2, 'r-o', 'DisplayName', '100ms Control Interval');
xlabel('Time [s]');
ylabel('Difference between RPMPulses and RPMdt');
title('Difference between RPMPulses and RPMdt as a Function of Time');
legend;
grid on;
hold off;
