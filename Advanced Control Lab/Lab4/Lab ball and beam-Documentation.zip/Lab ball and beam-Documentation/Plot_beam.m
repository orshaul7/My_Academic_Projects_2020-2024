figure(1)
fig=get(gcf);
if (isempty(fig.Children)||(~ishold))
    plot(data_x(:,1),data_x(:,2),data_x(:,1),data_x(:,3));
else    
    ax=get(fig.Children);
    number=size(get(ax.Children),1);
    switch number
        case 3
            colorExp='r';
        case 4
            colorExp='c';
        case 5
            colorExp='m';
        case 6
            colorExp='y';
        case 7
            colorExp='g';
        otherwise
            colorExp='k';
    end
    plot(data_x(:,1),data_x(:,3),colorExp);
end
grid on
title('Ball Position');
xlabel('Time [sec]');
ylabel('x [cm]');

figure(2)
fig=get(gcf);
if (isempty(fig.Children)||(~ishold))
    if (size(data_theta_l)>2)
        plot(data_theta_l(:,1),data_theta_l(:,2),data_theta_l(:,1),data_theta_l(:,3));
    else
        plot(data_theta_l(:,1),data_theta_l(:,2));
    end
else    
    ax=get(fig.Children);
    number=size(get(ax.Children),1);
    switch number
        case 3
            colorExp='r';
        case 4
            colorExp='c';
        case 5
            colorExp='m';
        case 6
            colorExp='y';
        case 7
            colorExp='g';
        otherwise
            colorExp='k';
    end
    plot(data_theta_l(:,1),data_theta_l(:,2),colorExp);
end
grid on
title('Motor Angle');
xlabel('Time [sec]');
ylabel('Theta_l [deg]');

if (exist('data_vm','var')~=0)
    figure(3)
    fig=get(gcf);
    if (isempty(fig.Children)||(~ishold))
        plot(data_vm(:,1),data_vm(:,2));
    else    
        ax=get(fig.Children);
        number=size(get(ax.Children),1);
        switch number
            case 3
                colorExp='r';
            case 4
                colorExp='c';
            case 5
                colorExp='m';
            case 6
                colorExp='y';
            case 7
                colorExp='g';
            otherwise
                colorExp='k';
        end
        plot(data_vm(:,1),data_vm(:,2),colorExp);
    end
    grid on
    title('Motor Input');
    xlabel('Time [sec]');
    ylabel('Voltage [V]');
end