% Define system parameters
s = tf('s'); 

% Enter the BB01 model gain found in Pre-Lab question 1
K_bb = 0.4178; % Replace with your actual value

% Enter the compensator gain Kc and the compensator zero z
K_c = 4.1; % Replace with your actual value
z = 1; % Replace with your actual value

% Define the transfer function for the practical PD compensator
PD_Compensator = K_c * (s + z);

% Define the BB01 open-loop transfer function
G = K_bb / s^2; % This is an example, adjust based on your actual system

% Open-loop transfer function with PD compensator
L = PD_Compensator * G;

% Plot the root locus
figure;
rlocus(L);
title('Root Locus of BB01 Loop Transfer Function with Practical PD Compensator');

% Add the desired pole locations using sgrid
% Specify the desired damping ratio and natural frequency for your system
zeta = 0.7; % Example damping ratio (adjust based on your requirements)
omega_n = 2; % Example natural frequency (adjust based on your requirements)
sgrid(zeta, omega_n);

% Customize the plot
grid on;

% Optionally, find the gain at a specific point interactively (if needed)
% Uncomment the following lines to use rlocfind interactively
% disp('Click on the desired pole location in the root locus plot:');
% [K, poles] = rlocfind(L);

% Display the calculated gain and poles (if rlocfind is used)
% disp('Calculated gain:');
% disp(K);
% disp('Poles at the calculated gain:');
% disp(poles);
