% Given parameters from the pre-lab
Kbb = 0.4178;
wn = 1.45;  % natural frequency
zeta = 0.59;  % damping ratio

% PD controller parameters
Kc = 4.1;  % gain
z = 1.227;  % zero location

% Define the transfer function for the BB01 system
s = tf('s');
Pbb = Kbb / s^2;

% Define the PD controller
C = Kc * (s + z);

% Open-loop transfer function
L = C * Pbb;

% Plot the root locus
figure;
rlocus(L);
title('Root Locus of the BB01 Loop Transfer Function with Ideal PD Controller');

% Desired pole locations
sgrid(zeta, wn);