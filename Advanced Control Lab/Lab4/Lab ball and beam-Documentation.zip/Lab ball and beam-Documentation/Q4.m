% Given parameters
K_bb = 1;  % Example value, replace with the actual value obtained from Pre-Lab Question 1
s = tf('s');

% Transfer function of the BB01 plant
P_bb = K_bb / s^2;

% Proportional controller gain
Kc = 1;  % Initial guess, can be varied to see the root locus behavior

% Open-loop transfer function
L = P_bb * Kc;

% Plot the root locus
figure;
rlocus(L);
title('Root Locus of the BB01 Plant');
xlabel('Real Axis');
ylabel('Imaginary Axis');
grid on;

% Include sgrid to show desired damping ratio and natural frequency lines
zeta = 0.591;  % Example damping ratio, replace with actual value
wn = 0.628;    % Example natural frequency, replace with actual value
sgrid(zeta, wn);
