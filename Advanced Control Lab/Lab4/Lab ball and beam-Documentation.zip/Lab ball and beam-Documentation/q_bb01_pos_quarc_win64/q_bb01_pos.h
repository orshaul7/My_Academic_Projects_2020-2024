/*
 * q_bb01_pos.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "q_bb01_pos".
 *
 * Model version              : 1.268
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jul  2 16:53:57 2024
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_q_bb01_pos_h_
#define RTW_HEADER_q_bb01_pos_h_
#include <float.h>
#include <math.h>
#include <string.h>
#ifndef q_bb01_pos_COMMON_INCLUDES_
# define q_bb01_pos_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "hil.h"
#include "quanser_messages.h"
#include "quanser_extern.h"
#endif                                 /* q_bb01_pos_COMMON_INCLUDES_ */

#include "q_bb01_pos_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T HILReadAnalogTimebase_o1;     /* '<S8>/HIL Read Analog Timebase' */
  real_T HILReadAnalogTimebase_o2;     /* '<S8>/HIL Read Analog Timebase' */
  real_T Clock;                        /* '<S13>/Clock' */
  real_T MultiportSwitch;              /* '<S13>/Multiport Switch' */
  real_T BB01CalibrationmV;            /* '<S8>/BB01 Calibration  (m//V)' */
  real_T SS01CalibrationmV;            /* '<S8>/SS01 Calibration  (m//V)' */
  real_T HILReadEncoder;               /* '<S8>/HIL Read Encoder' */
  real_T EncoderCalibrationradcount;   /* '<S8>/Encoder Calibration  (rad//count)' */
  real_T Bias;                         /* '<S8>/Bias' */
  real_T SquareWave;                   /* '<S7>/Square Wave' */
  real_T Clock_b;                      /* '<S11>/Clock' */
  real_T SineWave;                     /* '<S7>/Sine Wave' */
  real_T MultiportSwitch_o;            /* '<S7>/Multiport Switch' */
  real_T SliderGain;                   /* '<S1>/Slider Gain' */
  real_T SliderGain_n;                 /* '<S3>/Slider Gain' */
  real_T SetpointSource;               /* '<Root>/Setpoint Source' */
  real_T PositionErrorm;               /* '<S2>/Position Error (m)' */
  real_T ZeroLocationmrads;            /* '<S2>/Zero Location (m.rad//s)' */
  real_T SliderGain_j;                 /* '<S10>/Slider Gain' */
  real_T WeighedPositionErrorm;        /* '<S2>/Weighed Position Error (m)' */
  real_T HighPassFilterms;             /* '<S2>/High-Pass Filter (m//s)' */
  real_T ControlOutput;                /* '<S2>/Control  Output' */
  real_T ProportionalGain;             /* '<S2>/Proportional Gain ' */
  real_T Integrator;                   /* '<S2>/Integrator' */
  real_T Sum;                          /* '<S2>/Sum' */
  real_T DesiredAngleSaturationrad;    /* '<S2>/Desired Angle  Saturation (rad)' */
  real_T PositionErrorrad;             /* '<S6>/Position Error (rad)' */
  real_T ProportionalGainVrad;         /* '<S6>/Proportional Gain  (V//rad)' */
  real_T Highpassfilter;               /* '<S6>/High-pass filter' */
  real_T VelocityGainVsrad;            /* '<S6>/Velocity Gain  (V.s//rad)' */
  real_T ControlOutput_m;              /* '<S6>/Control  Output' */
  real_T DirectionConventionRightHandsys;/* '<S12>/Direction Convention: (Right-Hand) system' */
  real_T AmplifierSaturationV;         /* '<S12>/Amplifier  Saturation (V)' */
  real_T InverseAmplifierGainVV;       /* '<S12>/Inverse Amplifier  Gain (V//V)' */
  real_T DACBSaturationV;              /* '<S12>/DACB Saturation (V)' */
  real_T AmplifierGainVV;              /* '<S12>/Amplifier  Gain (V//V)' */
  real_T Gain[2];                      /* '<S5>/Gain' */
  real_T cmm[2];                       /* '<Root>/cm//m' */
  real_T SliderGain_c;                 /* '<S9>/Slider Gain' */
  real_T theta_ldeg;                   /* '<S6>/-theta_l (deg)' */
  real_T t;                            /* '<S11>/t' */
  real_T MultiportSwitch_c;            /* '<S11>/Multiport Switch' */
  real_T R0;                           /* '<S11>/R0' */
  real_T Sum_p;                        /* '<S11>/Sum' */
  real_T t12f;                         /* '<S11>/t-1//(2*f)' */
  real_T R0t12f;                       /* '<S11>/-R0*(t-1//(2*f))' */
  real_T Sum1;                         /* '<S11>/Sum1' */
  real_T Setpointcm;                   /* '<Root>/Setpoint (cm)' */
  real_T Setpointm;                    /* '<Root>/Setpoint (m)' */
  uint8_T Compare;                     /* '<S14>/Compare' */
  uint8_T Compare_j;                   /* '<S15>/Compare' */
  boolean_T LogicalOperator;           /* '<S13>/Logical Operator' */
  boolean_T t12f_m;                    /* '<S11>/t >= 1//(2*f)?' */
} B_q_bb01_pos_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T HILInitialize_AOVoltages[2];  /* '<S8>/HIL Initialize' */
  real_T HILReadAnalogTimebase_Buffer[2];/* '<S8>/HIL Read Analog Timebase' */
  t_task HILReadAnalogTimebase_Task;   /* '<S8>/HIL Read Analog Timebase' */
  t_card HILInitialize_Card;           /* '<S8>/HIL Initialize' */
  void *HILReadEncoder_PWORK;          /* '<S8>/HIL Read Encoder' */
  void *HILWriteAnalog_PWORK;          /* '<S8>/HIL Write Analog' */
  void *HILWriteDigital_PWORK;         /* '<S8>/HIL Write Digital' */
  struct {
    void *LoggedData;
  } VmV_PWORK;                         /* '<Root>/Vm (V)' */

  struct {
    void *LoggedData;
  } theta_ldeg_PWORK;                  /* '<Root>/theta_l (deg)' */

  struct {
    void *LoggedData;
  } xcm_PWORK;                         /* '<Root>/x (cm)' */

  int32_T HILReadEncoder_Buffer;       /* '<S8>/HIL Read Encoder' */
  boolean_T HILInitialize_DOBits[8];   /* '<S8>/HIL Initialize' */
  t_boolean HILWriteDigital_Buffer[4]; /* '<S8>/HIL Write Digital' */
} DW_q_bb01_pos_T;

/* Continuous states (default storage) */
typedef struct {
  real_T HighPassFilterms_CSTATE;      /* '<S2>/High-Pass Filter (m//s)' */
  real_T Integrator_CSTATE;            /* '<S2>/Integrator' */
  real_T Highpassfilter_CSTATE[2];     /* '<S6>/High-pass filter' */
} X_q_bb01_pos_T;

/* State derivatives (default storage) */
typedef struct {
  real_T HighPassFilterms_CSTATE;      /* '<S2>/High-Pass Filter (m//s)' */
  real_T Integrator_CSTATE;            /* '<S2>/Integrator' */
  real_T Highpassfilter_CSTATE[2];     /* '<S6>/High-pass filter' */
} XDot_q_bb01_pos_T;

/* State disabled  */
typedef struct {
  boolean_T HighPassFilterms_CSTATE;   /* '<S2>/High-Pass Filter (m//s)' */
  boolean_T Integrator_CSTATE;         /* '<S2>/Integrator' */
  boolean_T Highpassfilter_CSTATE[2];  /* '<S6>/High-pass filter' */
} XDis_q_bb01_pos_T;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* Parameters (default storage) */
struct P_q_bb01_pos_T_ {
  real_T K_AMP;                        /* Variable: K_AMP
                                        * Referenced by:
                                        *   '<S12>/Amplifier  Gain (V//V)'
                                        *   '<S12>/Inverse Amplifier  Gain (V//V)'
                                        */
  real_T K_BS;                         /* Variable: K_BS
                                        * Referenced by:
                                        *   '<S8>/BB01 Calibration  (m//V)'
                                        *   '<S8>/SS01 Calibration  (m//V)'
                                        */
  real_T K_ENC;                        /* Variable: K_ENC
                                        * Referenced by: '<S8>/Encoder Calibration  (rad//count)'
                                        */
  real_T Kc;                           /* Variable: Kc
                                        * Referenced by: '<S2>/Proportional Gain '
                                        */
  real_T THETA_MAX;                    /* Variable: THETA_MAX
                                        * Referenced by:
                                        *   '<S2>/Integrator'
                                        *   '<S2>/Desired Angle  Saturation (rad)'
                                        */
  real_T THETA_MIN;                    /* Variable: THETA_MIN
                                        * Referenced by:
                                        *   '<S2>/Integrator'
                                        *   '<S2>/Desired Angle  Saturation (rad)'
                                        */
  real_T THETA_OFF;                    /* Variable: THETA_OFF
                                        * Referenced by: '<S8>/Bias'
                                        */
  real_T VMAX_AMP;                     /* Variable: VMAX_AMP
                                        * Referenced by: '<S12>/Amplifier  Saturation (V)'
                                        */
  real_T VMAX_DAC;                     /* Variable: VMAX_DAC
                                        * Referenced by: '<S12>/DACB Saturation (V)'
                                        */
  real_T kp;                           /* Variable: kp
                                        * Referenced by: '<S6>/Proportional Gain  (V//rad)'
                                        */
  real_T kv;                           /* Variable: kv
                                        * Referenced by: '<S6>/Velocity Gain  (V.s//rad)'
                                        */
  real_T z;                            /* Variable: z
                                        * Referenced by: '<S2>/Zero Location (m.rad//s)'
                                        */
  real_T SRV02SignalGenerator_a;       /* Mask Parameter: SRV02SignalGenerator_a
                                        * Referenced by:
                                        *   '<S7>/Sine Wave'
                                        *   '<S7>/Square Wave'
                                        *   '<S11>/Amplitude'
                                        *   '<S11>/-R0*(t-1//(2*f))'
                                        *   '<S11>/R0'
                                        */
  real_T InitialTimes_const;           /* Mask Parameter: InitialTimes_const
                                        * Referenced by: '<S14>/Constant'
                                        */
  real_T ReadingZero_const;            /* Mask Parameter: ReadingZero_const
                                        * Referenced by: '<S15>/Constant'
                                        */
  real_T SRV02SignalGenerator_f;       /* Mask Parameter: SRV02SignalGenerator_f
                                        * Referenced by:
                                        *   '<S7>/Sine Wave'
                                        *   '<S7>/Square Wave'
                                        *   '<S11>/Half Period (s)'
                                        *   '<S11>/Period (s)'
                                        *   '<S11>/-R0*(t-1//(2*f))'
                                        *   '<S11>/R0'
                                        */
  real_T Amplitudecm_gain;             /* Mask Parameter: Amplitudecm_gain
                                        * Referenced by: '<S1>/Slider Gain'
                                        */
  real_T Constantcm_gain;              /* Mask Parameter: Constantcm_gain
                                        * Referenced by: '<S3>/Slider Gain'
                                        */
  real_T SetPointWeight_gain;          /* Mask Parameter: SetPointWeight_gain
                                        * Referenced by: '<S10>/Slider Gain'
                                        */
  real_T IntegralGainradms_gain;       /* Mask Parameter: IntegralGainradms_gain
                                        * Referenced by: '<S9>/Slider Gain'
                                        */
  real_T SRV02SignalGenerator_sig_type;/* Mask Parameter: SRV02SignalGenerator_sig_type
                                        * Referenced by: '<S7>/Constant'
                                        */
  int32_T HILReadAnalogTimebase_clock; /* Mask Parameter: HILReadAnalogTimebase_clock
                                        * Referenced by: '<S8>/HIL Read Analog Timebase'
                                        */
  uint32_T HILReadAnalogTimebase_channels[2];/* Mask Parameter: HILReadAnalogTimebase_channels
                                              * Referenced by: '<S8>/HIL Read Analog Timebase'
                                              */
  uint32_T HILReadEncoder_channels;    /* Mask Parameter: HILReadEncoder_channels
                                        * Referenced by: '<S8>/HIL Read Encoder'
                                        */
  uint32_T HILWriteAnalog_channels;    /* Mask Parameter: HILWriteAnalog_channels
                                        * Referenced by: '<S8>/HIL Write Analog'
                                        */
  uint32_T HILWriteDigital_channels[4];/* Mask Parameter: HILWriteDigital_channels
                                        * Referenced by: '<S8>/HIL Write Digital'
                                        */
  uint32_T HILReadAnalogTimebase_samples_i;/* Mask Parameter: HILReadAnalogTimebase_samples_i
                                            * Referenced by: '<S8>/HIL Read Analog Timebase'
                                            */
  real_T Setpointm_Gain;               /* Expression: 0.01
                                        * Referenced by: '<Root>/Setpoint (m)'
                                        */
  real_T HILInitialize_OOTerminate;    /* Expression: set_other_outputs_at_terminate
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  real_T HILInitialize_OOExit;         /* Expression: set_other_outputs_at_switch_out
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  real_T HILInitialize_AOFinal;        /* Expression: final_analog_outputs
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  real_T HILInitialize_POFinal;        /* Expression: final_pwm_outputs
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  real_T Constant_Value;               /* Expression: -4.5
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T Constant_Value_a;             /* Expression: 1
                                        * Referenced by: '<Root>/Constant '
                                        */
  real_T HighPassFilterms_A;           /* Computed Parameter: HighPassFilterms_A
                                        * Referenced by: '<S2>/High-Pass Filter (m//s)'
                                        */
  real_T HighPassFilterms_C;           /* Computed Parameter: HighPassFilterms_C
                                        * Referenced by: '<S2>/High-Pass Filter (m//s)'
                                        */
  real_T HighPassFilterms_D;           /* Computed Parameter: HighPassFilterms_D
                                        * Referenced by: '<S2>/High-Pass Filter (m//s)'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<S2>/Integrator'
                                        */
  real_T Highpassfilter_A[2];          /* Computed Parameter: Highpassfilter_A
                                        * Referenced by: '<S6>/High-pass filter'
                                        */
  real_T Highpassfilter_C[2];          /* Computed Parameter: Highpassfilter_C
                                        * Referenced by: '<S6>/High-pass filter'
                                        */
  real_T DirectionConventionRightHandsys;/* Expression: -1
                                          * Referenced by: '<S12>/Direction Convention: (Right-Hand) system'
                                          */
  real_T EnableVoltPAQX2X4_Value[4];   /* Expression: [1 1 1 1]
                                        * Referenced by: '<S8>/Enable VoltPAQ-X2,X4'
                                        */
  real_T Gain_Gain;                    /* Expression: 180/pi
                                        * Referenced by: '<S5>/Gain'
                                        */
  real_T cmm_Gain;                     /* Expression: 100
                                        * Referenced by: '<Root>/cm//m'
                                        */
  real_T theta_ldeg_Gain;              /* Expression: -1
                                        * Referenced by: '<S6>/-theta_l (deg)'
                                        */
  boolean_T HILInitialize_Active;      /* Computed Parameter: HILInitialize_Active
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_AOTerminate; /* Computed Parameter: HILInitialize_AOTerminate
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_AOExit;      /* Computed Parameter: HILInitialize_AOExit
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_DOTerminate; /* Computed Parameter: HILInitialize_DOTerminate
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_DOExit;      /* Computed Parameter: HILInitialize_DOExit
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_POTerminate; /* Computed Parameter: HILInitialize_POTerminate
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_POExit;      /* Computed Parameter: HILInitialize_POExit
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILInitialize_DOFinal;     /* Computed Parameter: HILInitialize_DOFinal
                                        * Referenced by: '<S8>/HIL Initialize'
                                        */
  boolean_T HILReadAnalogTimebase_Active;/* Computed Parameter: HILReadAnalogTimebase_Active
                                          * Referenced by: '<S8>/HIL Read Analog Timebase'
                                          */
  boolean_T HILReadEncoder_Active;     /* Computed Parameter: HILReadEncoder_Active
                                        * Referenced by: '<S8>/HIL Read Encoder'
                                        */
  boolean_T HILWriteAnalog_Active;     /* Computed Parameter: HILWriteAnalog_Active
                                        * Referenced by: '<S8>/HIL Write Analog'
                                        */
  boolean_T HILWriteDigital_Active;    /* Computed Parameter: HILWriteDigital_Active
                                        * Referenced by: '<S8>/HIL Write Digital'
                                        */
  uint8_T SetpointSource_CurrentSetting;/* Computed Parameter: SetpointSource_CurrentSetting
                                         * Referenced by: '<Root>/Setpoint Source'
                                         */
};

/* Real-time Model Data Structure */
struct tag_RTM_q_bb01_pos_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  X_q_bb01_pos_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][4];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_q_bb01_pos_T q_bb01_pos_P;

/* Block signals (default storage) */
extern B_q_bb01_pos_T q_bb01_pos_B;

/* Continuous states (default storage) */
extern X_q_bb01_pos_T q_bb01_pos_X;

/* Block states (default storage) */
extern DW_q_bb01_pos_T q_bb01_pos_DW;

/* Model entry point functions */
extern void q_bb01_pos_initialize(void);
extern void q_bb01_pos_step(void);
extern void q_bb01_pos_terminate(void);

/* Real-time Model object */
extern RT_MODEL_q_bb01_pos_T *const q_bb01_pos_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'q_bb01_pos'
 * '<S1>'   : 'q_bb01_pos/Amplitude  (cm)'
 * '<S2>'   : 'q_bb01_pos/BB01 PD  Position Control'
 * '<S3>'   : 'q_bb01_pos/Constant  (cm)'
 * '<S4>'   : 'q_bb01_pos/Powered by QUARC'
 * '<S5>'   : 'q_bb01_pos/Radians to Degrees'
 * '<S6>'   : 'q_bb01_pos/SRV02 PV  Position Control'
 * '<S7>'   : 'q_bb01_pos/SRV02 Signal  Generator'
 * '<S8>'   : 'q_bb01_pos/SRV02-ET+BB01'
 * '<S9>'   : 'q_bb01_pos/BB01 PD  Position Control/Integral Gain (rad//m//s)'
 * '<S10>'  : 'q_bb01_pos/BB01 PD  Position Control/Set-Point Weight'
 * '<S11>'  : 'q_bb01_pos/SRV02 Signal  Generator/Triangle Wave'
 * '<S12>'  : 'q_bb01_pos/SRV02-ET+BB01/Actuator Dynamics'
 * '<S13>'  : 'q_bb01_pos/SRV02-ET+BB01/Sensor Deadband  Detection'
 * '<S14>'  : 'q_bb01_pos/SRV02-ET+BB01/Sensor Deadband  Detection/Initial Time (s)'
 * '<S15>'  : 'q_bb01_pos/SRV02-ET+BB01/Sensor Deadband  Detection/Reading Zero?'
 */
#endif                                 /* RTW_HEADER_q_bb01_pos_h_ */
