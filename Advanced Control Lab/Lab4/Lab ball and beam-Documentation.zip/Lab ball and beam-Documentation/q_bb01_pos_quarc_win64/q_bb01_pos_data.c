/*
 * q_bb01_pos_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "q_bb01_pos".
 *
 * Model version              : 1.268
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jul  2 16:53:57 2024
 *
 * Target selection: quarc_win64.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "q_bb01_pos.h"
#include "q_bb01_pos_private.h"

/* Block parameters (default storage) */
P_q_bb01_pos_T q_bb01_pos_P = {
  /* Variable: K_AMP
   * Referenced by:
   *   '<S12>/Amplifier  Gain (V//V)'
   *   '<S12>/Inverse Amplifier  Gain (V//V)'
   */
  3.0,

  /* Variable: K_BS
   * Referenced by:
   *   '<S8>/BB01 Calibration  (m//V)'
   *   '<S8>/SS01 Calibration  (m//V)'
   */
  -0.042545,

  /* Variable: K_ENC
   * Referenced by: '<S8>/Encoder Calibration  (rad//count)'
   */
  0.0015339807878856412,

  /* Variable: Kc
   * Referenced by: '<S2>/Proportional Gain '
   */
  3.5,

  /* Variable: THETA_MAX
   * Referenced by:
   *   '<S2>/Integrator'
   *   '<S2>/Desired Angle  Saturation (rad)'
   */
  0.97738438111682457,

  /* Variable: THETA_MIN
   * Referenced by:
   *   '<S2>/Integrator'
   *   '<S2>/Desired Angle  Saturation (rad)'
   */
  -0.97738438111682457,

  /* Variable: THETA_OFF
   * Referenced by: '<S8>/Bias'
   */
  -0.97738438111682457,

  /* Variable: VMAX_AMP
   * Referenced by: '<S12>/Amplifier  Saturation (V)'
   */
  24.0,

  /* Variable: VMAX_DAC
   * Referenced by: '<S12>/DACB Saturation (V)'
   */
  10.0,

  /* Variable: kp
   * Referenced by: '<S6>/Proportional Gain  (V//rad)'
   */
  13.5,

  /* Variable: kv
   * Referenced by: '<S6>/Velocity Gain  (V.s//rad)'
   */
  0.078,

  /* Variable: z
   * Referenced by: '<S2>/Zero Location (m.rad//s)'
   */
  1.0,

  /* Mask Parameter: SRV02SignalGenerator_a
   * Referenced by:
   *   '<S7>/Sine Wave'
   *   '<S7>/Square Wave'
   *   '<S11>/Amplitude'
   *   '<S11>/-R0*(t-1//(2*f))'
   *   '<S11>/R0'
   */
  1.0,

  /* Mask Parameter: InitialTimes_const
   * Referenced by: '<S14>/Constant'
   */
  0.1,

  /* Mask Parameter: ReadingZero_const
   * Referenced by: '<S15>/Constant'
   */
  0.05,

  /* Mask Parameter: SRV02SignalGenerator_f
   * Referenced by:
   *   '<S7>/Sine Wave'
   *   '<S7>/Square Wave'
   *   '<S11>/Half Period (s)'
   *   '<S11>/Period (s)'
   *   '<S11>/-R0*(t-1//(2*f))'
   *   '<S11>/R0'
   */
  0.05,

  /* Mask Parameter: Amplitudecm_gain
   * Referenced by: '<S1>/Slider Gain'
   */
  5.0,

  /* Mask Parameter: Constantcm_gain
   * Referenced by: '<S3>/Slider Gain'
   */
  0.0,

  /* Mask Parameter: SetPointWeight_gain
   * Referenced by: '<S10>/Slider Gain'
   */
  0.0,

  /* Mask Parameter: IntegralGainradms_gain
   * Referenced by: '<S9>/Slider Gain'
   */
  0.0,

  /* Mask Parameter: SRV02SignalGenerator_sig_type
   * Referenced by: '<S7>/Constant'
   */
  1.0,

  /* Mask Parameter: HILReadAnalogTimebase_clock
   * Referenced by: '<S8>/HIL Read Analog Timebase'
   */
  0,

  /* Mask Parameter: HILReadAnalogTimebase_channels
   * Referenced by: '<S8>/HIL Read Analog Timebase'
   */
  { 0U, 1U },

  /* Mask Parameter: HILReadEncoder_channels
   * Referenced by: '<S8>/HIL Read Encoder'
   */
  0U,

  /* Mask Parameter: HILWriteAnalog_channels
   * Referenced by: '<S8>/HIL Write Analog'
   */
  0U,

  /* Mask Parameter: HILWriteDigital_channels
   * Referenced by: '<S8>/HIL Write Digital'
   */
  { 0U, 1U, 2U, 3U },

  /* Mask Parameter: HILReadAnalogTimebase_samples_i
   * Referenced by: '<S8>/HIL Read Analog Timebase'
   */
  1000U,

  /* Expression: 0.01
   * Referenced by: '<Root>/Setpoint (m)'
   */
  0.01,

  /* Expression: set_other_outputs_at_terminate
   * Referenced by: '<S8>/HIL Initialize'
   */
  0.0,

  /* Expression: set_other_outputs_at_switch_out
   * Referenced by: '<S8>/HIL Initialize'
   */
  0.0,

  /* Expression: final_analog_outputs
   * Referenced by: '<S8>/HIL Initialize'
   */
  0.0,

  /* Expression: final_pwm_outputs
   * Referenced by: '<S8>/HIL Initialize'
   */
  0.0,

  /* Expression: -4.5
   * Referenced by: '<S13>/Constant'
   */
  -4.5,

  /* Expression: 1
   * Referenced by: '<Root>/Constant '
   */
  1.0,

  /* Computed Parameter: HighPassFilterms_A
   * Referenced by: '<S2>/High-Pass Filter (m//s)'
   */
  -10.0,

  /* Computed Parameter: HighPassFilterms_C
   * Referenced by: '<S2>/High-Pass Filter (m//s)'
   */
  -100.0,

  /* Computed Parameter: HighPassFilterms_D
   * Referenced by: '<S2>/High-Pass Filter (m//s)'
   */
  10.0,

  /* Expression: 0
   * Referenced by: '<S2>/Integrator'
   */
  0.0,

  /* Computed Parameter: Highpassfilter_A
   * Referenced by: '<S6>/High-pass filter'
   */
  { -565.48667764616278, -98696.044010893587 },

  /* Computed Parameter: Highpassfilter_C
   * Referenced by: '<S6>/High-pass filter'
   */
  { 98696.044010893587, 0.0 },

  /* Expression: -1
   * Referenced by: '<S12>/Direction Convention: (Right-Hand) system'
   */
  -1.0,

  /* Expression: [1 1 1 1]
   * Referenced by: '<S8>/Enable VoltPAQ-X2,X4'
   */
  { 1.0, 1.0, 1.0, 1.0 },

  /* Expression: 180/pi
   * Referenced by: '<S5>/Gain'
   */
  57.295779513082323,

  /* Expression: 100
   * Referenced by: '<Root>/cm//m'
   */
  100.0,

  /* Expression: -1
   * Referenced by: '<S6>/-theta_l (deg)'
   */
  -1.0,

  /* Computed Parameter: HILInitialize_Active
   * Referenced by: '<S8>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_AOTerminate
   * Referenced by: '<S8>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_AOExit
   * Referenced by: '<S8>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOTerminate
   * Referenced by: '<S8>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_DOExit
   * Referenced by: '<S8>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_POTerminate
   * Referenced by: '<S8>/HIL Initialize'
   */
  1,

  /* Computed Parameter: HILInitialize_POExit
   * Referenced by: '<S8>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILInitialize_DOFinal
   * Referenced by: '<S8>/HIL Initialize'
   */
  0,

  /* Computed Parameter: HILReadAnalogTimebase_Active
   * Referenced by: '<S8>/HIL Read Analog Timebase'
   */
  1,

  /* Computed Parameter: HILReadEncoder_Active
   * Referenced by: '<S8>/HIL Read Encoder'
   */
  1,

  /* Computed Parameter: HILWriteAnalog_Active
   * Referenced by: '<S8>/HIL Write Analog'
   */
  0,

  /* Computed Parameter: HILWriteDigital_Active
   * Referenced by: '<S8>/HIL Write Digital'
   */
  0,

  /* Computed Parameter: SetpointSource_CurrentSetting
   * Referenced by: '<Root>/Setpoint Source'
   */
  1U
};
