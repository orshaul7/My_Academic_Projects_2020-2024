% Load the simulation data (assuming data_x and data_theta_l are in the workspace)
% If they are not, make sure to load them appropriately.

% data_x(:,1) is the time vector
% data_x(:,2) is the setpoint
% data_x(:,3) is the simulated ball position
% data_theta_l(:,1) is the time vector
% data_theta_l(:,2) is the servo angle

% Check if variables exist in the workspace
if exist('data_x', 'var') && exist('data_theta_l', 'var')
    % Extract data
    time_x = data_x(:, 1);
    setpoint = data_x(:, 2);
    ball_position = data_x(:, 3);
    
    time_theta_l = data_theta_l(:, 1);
    servo_angle = data_theta_l(:, 2);

    % Plot ball position response
    figure;
    subplot(2, 1, 1);
    plot(time_x, setpoint, 'r--', 'LineWidth', 1.5);
    hold on;
    plot(time_x, ball_position, 'b', 'LineWidth', 1.5);
    xlabel('Time (s)');
    ylabel('Ball Position (m)');
    title('Nonlinear Outer-Loop BB01 Ball Position Response');
    legend('Setpoint', 'Ball Position');
    grid on;

    % Plot servo angle response
    subplot(2, 1, 2);
    plot(time_theta_l, servo_angle, 'k', 'LineWidth', 1.5);
    xlabel('Time (s)');
    ylabel('Servo Angle (deg)');
    title('Servo Angle Response');
    grid on;

else
    error('The required variables data_x and/or data_theta_l are not in the workspace.');
end
