% Define system parameters
s = tf('s'); 

% Define the transfer function for the practical PD compensator
PD_Compensator = s*wf /(s + wf);

% Define the BB01 open-loop transfer function
G = K_bb / s^2; % This is an example, adjust based on your actual system

% Open-loop transfer function with PD compensator
L = PD_Compensator * G;

% Plot the root locus
figure;
rlocus(L);
title('Root Locus of BB01 Loop Transfer Function with Practical PD Compensator');

% Add the desired pole locations using sgrid
% Specify the desired damping ratio and natural frequency for your system
 

% Customize the plot
grid on;

% Optionally, find the gain at a specific point interactively (if needed)
% Uncomment the following lines to use rlocfind interactively
% disp('Click on the desired pole location in the root locus plot:');
% [K, poles] = rlocfind(L);


