% Given transfer function
num = [1];
den = [1, 3, 0, 0];
sys = tf(num, den);

% Compensator transfer function
cnum = [1.15, 1];
cden = [0.15, 1];
comp = tf(cnum, cden);

% Open-loop transfer function with compensator
sys_open_loop = comp * sys;

% Nyquist plot
figure;
nyqlog(sys_open_loop);
title('Nyquist Plot of C*P System');