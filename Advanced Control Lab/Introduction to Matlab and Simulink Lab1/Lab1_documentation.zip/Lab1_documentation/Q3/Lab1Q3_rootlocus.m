ver control;
num = [1];
den = [1,3,0,0];
sys = tf(num,den);
cnum = [1.15,1];
cden=[0.15,1];
comp=tf(cnum,cden);
sys_open_loop = comp * sys;
rlocus(sys_open_loop);