% Given transfer function
num = [1];
den = [1, 3, 0, 0];
sys = tf(num, den);

% Compensator transfer function
cnum = [1.15, 1];
cden = [0.15, 1];
comp = tf(cnum, cden);

% Calculate K values
K1 = 15/2; %kcr / 2
K2 = 15+1; %kcr + 1

% Create closed-loop systems with different K values
sys_closed_loop1 = feedback(K1 * comp * sys, 1);
sys_closed_loop2 = feedback(K2 * comp * sys, 1);

% Plot for K = kcr/2
subplot(2,1,1);
step(sys_closed_loop1);
title('Step Response for K = kcr/2');

% Plot for K = kcr+1
subplot(2,1,2);
step(sys_closed_loop2);
title('Step Response for K = kcr+1');