ver control;
num = [1];
den = [1,3,0,0]
sys=tf(num,den);
[A,B,C,D]=tf2ss(num,den)
[num1,den1]=ss2tf(A,B,C,D)
