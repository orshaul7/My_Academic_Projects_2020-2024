% Given transfer function
num = [1];
den = [1, 3, 0, 0];

% Convert transfer function to state-space representation
[A, B, C, D] = tf2ss(num, den);

% Display state-space matrices
disp('A matrix:');
disp(A);
disp('B matrix:');
disp(B);
disp('C matrix:');
disp(C);
disp('D matrix:');
disp(D);

% Simulate the system's step response
sys_ss = ss(A, B, C, D);
step(sys_ss);