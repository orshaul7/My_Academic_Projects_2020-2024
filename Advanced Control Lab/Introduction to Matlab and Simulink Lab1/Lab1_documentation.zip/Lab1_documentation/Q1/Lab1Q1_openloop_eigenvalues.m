% Given A matrix
A = [0 1 0; 0 0 1; 0 0 -3];

% Find eigenvalues of A matrix
eigenvalues = eig(A);

% Display eigenvalues
disp('Eigenvalues:');
disp(eigenvalues);
