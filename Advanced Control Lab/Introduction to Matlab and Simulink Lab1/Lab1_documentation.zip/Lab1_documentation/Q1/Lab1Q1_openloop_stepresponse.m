ver control;
sys = tf([1],[1,3,0,0]);
step(sys);