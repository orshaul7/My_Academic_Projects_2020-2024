% Define the x vector
x = 0:1:4;

% Define the K vector
K = [1, 7.5, 16];

% Define the numerator and denominator for the transfer function
num = [1.15, 1]; % Coefficients of the numerator [1.15s + 1]
den = [0.15, 1.45, 3, 0, 0]; % Coefficients of the denominator [0.15s^3 + 3.15s^2 + 3.15s + 9]

% Create the transfer function
sys = tf(num, den);

% Loop for different values of K
for i = 1:3
    figure(i);

    % Get the current value of K
    k = K(i);

    % Compute the closed-loop system
    closed_sys = feedback(k * sys, 1);

    % Simulate the step response of the closed-loop system
    [y, t] = step(closed_sys);

    % Run the Simulink model 'close_loop.slx'
    simout2 = sim('close_loop.slx');

    % Extract the simulation results
    time = simout2.get('CloseLoop').time;
    output = simout2.get('CloseLoop').signals.values;

    % Plot the Simulink simulation result
    plot(time, output(:, 1), '--b', 'DisplayName', 'Step Function');
    hold on;

    % Plot the MATLAB step response
    plot(t, y, ':r', 'LineWidth', 1.5, 'DisplayName', 'MATLAB Step Response');

    % Add grid and labels
    grid on;
    title(['Closed-Loop Response for K = ', num2str(k)]);
    xlabel('Time [s]');
    ylabel('Response');
    legend('show');
    hold off;
end
