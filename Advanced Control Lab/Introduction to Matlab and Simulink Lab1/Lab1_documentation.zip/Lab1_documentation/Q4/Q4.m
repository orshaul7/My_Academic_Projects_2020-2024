% Set the gain value in the workspace
K = 1;

% Run the simulation
simOut = sim('open_loop');

% Extract the results
time = simOut.get('SysResponse').time;
output = simOut.get('SysResponse').signals.values;

% Plot the results
figure;
hold on;
plot(time, output(:, 1), 'b', 'DisplayName', 'Step Function');
plot(time, output(:, 2), 'r', 'DisplayName', 'Step Response');
hold off;

% Add grid, title, axis labels, and legend
grid on;
title('Open System Response to step function input');
xlabel('Time [s]');
ylabel('Step Response');
legend('Step Function', 'Step Response');
