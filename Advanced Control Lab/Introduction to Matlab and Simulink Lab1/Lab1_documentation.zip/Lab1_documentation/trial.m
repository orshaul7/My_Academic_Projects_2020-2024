x=0:1:4;
num=x(2);
den=[x(3:5), x(1)];
sys=tf(num,den);
K=1;
mdl = "close_loop";% simulink name
open_system(mdl) % open simulation
for i=1:3
 figure(i);
 K=i*1.5;
 [y,t]=step(feedback(K*sys,1)); 
 set_param(mdl,"SimulationCommand","start") % run simulation
 pause(1) % wait for the simulation to finish
 set_param(mdl,"SimulationCommand","writedatalogs"); % write logs to desktop
 plot(out.CloseLoop.time,out.CloseLoop.signals.values(:,2),'--r');
 hold on
 plot(t,y,':b','LineWidth',1.5);
 if i==1
     legend('simulation step response', 'matlab step response')
 end
 grid on
 hold off 
 pause(1) % wait for the plot update
end
