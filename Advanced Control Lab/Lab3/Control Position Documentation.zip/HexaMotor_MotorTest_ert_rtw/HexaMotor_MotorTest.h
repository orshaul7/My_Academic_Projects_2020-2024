/*
 * HexaMotor_MotorTest.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HexaMotor_MotorTest".
 *
 * Model version              : 6.65
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 14:39:25 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HexaMotor_MotorTest_h_
#define RTW_HEADER_HexaMotor_MotorTest_h_
#ifndef HexaMotor_MotorTest_COMMON_INCLUDES_
#define HexaMotor_MotorTest_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_mode.h"
#include "MW_I2C.h"
#include "MW_PWM.h"
#include "MW_arduino_digitalio.h"
#endif                                /* HexaMotor_MotorTest_COMMON_INCLUDES_ */

#include "HexaMotor_MotorTest_types.h"
#include "rtGetInf.h"
#include <string.h>
#include "rt_nonfinite.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Probe[2];                     /* '<S5>/Probe' */
  real_T Voltage;                      /* '<Root>/Open Loop' */
  real_T Saturation;                   /* '<S11>/Saturation' */
  real_T TmpSignalConversionAtTAQSigLogg[2];
  /* '<Root>/TmpSignal ConversionAtTAQSigLogging_InsertedFor_Mux2_at_outport_0Inport1' */
  real_T Clock;                        /* '<S3>/Clock' */
  real_T Diff;                         /* '<S12>/Diff' */
} B_HexaMotor_MotorTest_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  motorcarrier_blocks_mkrmotorc_T obj; /* '<Root>/Encoder 1' */
  codertarget_arduinobase_block_T obj_n;/* '<S3>/Digital Output' */
  codertarget_arduinobase_inter_T obj_i;/* '<S1>/Reverse PWM' */
  codertarget_arduinobase_inter_T obj_g;/* '<S1>/Forward PWM' */
  real_T Integrator_DSTATE;            /* '<S11>/Integrator' */
  real_T UD_DSTATE;                    /* '<S12>/UD' */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */

  boolean_T Delay_DSTATE;              /* '<S3>/Delay' */
  int8_T Integrator_PrevResetState;    /* '<S11>/Integrator' */
  uint8_T Integrator_IC_LOADING;       /* '<S11>/Integrator' */
} DW_HexaMotor_MotorTest_T;

/* Parameters (default storage) */
struct P_HexaMotor_MotorTest_T_ {
  real_T Difference_ICPrevInput;       /* Mask Parameter: Difference_ICPrevInput
                                        * Referenced by: '<S12>/UD'
                                        */
  real_T LowPassFilterDiscreteorContinuo;
                              /* Mask Parameter: LowPassFilterDiscreteorContinuo
                               * Referenced by: '<S4>/K'
                               */
  real_T LowPassFilterDiscreteorContin_g;
                              /* Mask Parameter: LowPassFilterDiscreteorContin_g
                               * Referenced by: '<S5>/Time constant'
                               */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S8>/Constant'
                                       */
  real_T LowPassFilterDiscreteorContin_n;
                              /* Mask Parameter: LowPassFilterDiscreteorContin_n
                               * Referenced by: '<S5>/Constant'
                               */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S9>/Constant'
                                        */
  real_T PPR_1_Gain;                   /* Expression: 1/48
                                        * Referenced by: '<S2>/PPR_1'
                                        */
  real_T Gear_Gain;                    /* Expression: 1/20.4
                                        * Referenced by: '<S2>/Gear'
                                        */
  real_T Gain1_Gain;                   /* Expression: 2*pi
                                        * Referenced by: '<S2>/Gain1'
                                        */
  real_T OpenLoop_Value;               /* Expression: 0.4915351666079459
                                        * Referenced by: '<Root>/Open Loop'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 12
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -12
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Gain2_Gain;                   /* Expression: 255/12
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S11>/Integrator'
                                        */
  real_T Integrator_UpperSat;          /* Expression: antiwindupUpperLimit
                                        * Referenced by: '<S11>/Integrator'
                                        */
  real_T Integrator_LowerSat;          /* Expression: antiwindupLowerLimit
                                        * Referenced by: '<S11>/Integrator'
                                        */
  real_T Saturation_UpperSat_m;        /* Expression: windupUpperLimit
                                        * Referenced by: '<S11>/Saturation'
                                        */
  real_T Saturation_LowerSat_k;        /* Expression: windupLowerLimit
                                        * Referenced by: '<S11>/Saturation'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S3>/Constant1'
                                        */
  int16_T Constant1_Value_b;           /* Computed Parameter: Constant1_Value_b
                                        * Referenced by: '<S1>/Constant1'
                                        */
  int16_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S1>/Switch'
                                        */
  boolean_T Delay_InitialCondition;/* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S3>/Delay'
                                    */
};

/* Real-time Model Data Structure */
struct tag_RTM_HexaMotor_MotorTest_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_HexaMotor_MotorTest_T HexaMotor_MotorTest_P;

/* Block signals (default storage) */
extern B_HexaMotor_MotorTest_T HexaMotor_MotorTest_B;

/* Block states (default storage) */
extern DW_HexaMotor_MotorTest_T HexaMotor_MotorTest_DW;

/* Model entry point functions */
extern void HexaMotor_MotorTest_initialize(void);
extern void HexaMotor_MotorTest_step(void);
extern void HexaMotor_MotorTest_terminate(void);

/* Real-time Model object */
extern RT_MODEL_HexaMotor_MotorTest_T *const HexaMotor_MotorTest_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HexaMotor_MotorTest'
 * '<S1>'   : 'HexaMotor_MotorTest/M3 M4 DC Motors'
 * '<S2>'   : 'HexaMotor_MotorTest/Subsystem'
 * '<S3>'   : 'HexaMotor_MotorTest/System SampleRate'
 * '<S4>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)'
 * '<S5>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant'
 * '<S6>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Initialization'
 * '<S7>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Integrator (Discrete or Continuous)'
 * '<S8>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant/Compare To Constant'
 * '<S9>'   : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant/Compare To Zero'
 * '<S10>'  : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Initialization/Init_u'
 * '<S11>'  : 'HexaMotor_MotorTest/Subsystem/Low-Pass Filter (Discrete or Continuous)/Integrator (Discrete or Continuous)/Discrete'
 * '<S12>'  : 'HexaMotor_MotorTest/System SampleRate/Difference'
 */
#endif                                 /* RTW_HEADER_HexaMotor_MotorTest_h_ */
