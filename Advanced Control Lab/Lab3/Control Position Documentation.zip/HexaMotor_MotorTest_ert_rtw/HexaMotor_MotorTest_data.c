/*
 * HexaMotor_MotorTest_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HexaMotor_MotorTest".
 *
 * Model version              : 6.65
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 14:39:25 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "HexaMotor_MotorTest.h"

/* Block parameters (default storage) */
P_HexaMotor_MotorTest_T HexaMotor_MotorTest_P = {
  /* Mask Parameter: Difference_ICPrevInput
   * Referenced by: '<S12>/UD'
   */
  0.0,

  /* Mask Parameter: LowPassFilterDiscreteorContinuo
   * Referenced by: '<S4>/K'
   */
  1.0,

  /* Mask Parameter: LowPassFilterDiscreteorContin_g
   * Referenced by: '<S5>/Time constant'
   */
  0.05,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S8>/Constant'
   */
  2.0,

  /* Mask Parameter: LowPassFilterDiscreteorContin_n
   * Referenced by: '<S5>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S9>/Constant'
   */
  0.0,

  /* Expression: 1/48
   * Referenced by: '<S2>/PPR_1'
   */
  0.020833333333333332,

  /* Expression: 1/20.4
   * Referenced by: '<S2>/Gear'
   */
  0.049019607843137261,

  /* Expression: 2*pi
   * Referenced by: '<S2>/Gain1'
   */
  6.2831853071795862,

  /* Expression: 0.4915351666079459
   * Referenced by: '<Root>/Open Loop'
   */
  0.49153516660794588,

  /* Expression: 12
   * Referenced by: '<Root>/Saturation'
   */
  12.0,

  /* Expression: -12
   * Referenced by: '<Root>/Saturation'
   */
  -12.0,

  /* Expression: 255/12
   * Referenced by: '<Root>/Gain2'
   */
  21.25,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S11>/Integrator'
   */
  0.01,

  /* Expression: antiwindupUpperLimit
   * Referenced by: '<S11>/Integrator'
   */
  0.0,

  /* Expression: antiwindupLowerLimit
   * Referenced by: '<S11>/Integrator'
   */
  0.0,

  /* Expression: windupUpperLimit
   * Referenced by: '<S11>/Saturation'
   */
  0.0,

  /* Expression: windupLowerLimit
   * Referenced by: '<S11>/Saturation'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S3>/Constant1'
   */
  1.0,

  /* Computed Parameter: Constant1_Value_b
   * Referenced by: '<S1>/Constant1'
   */
  0,

  /* Computed Parameter: Switch_Threshold
   * Referenced by: '<S1>/Switch'
   */
  0,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S3>/Delay'
   */
  false
};
