/*
 * rtmodel.h
 *
 * Code generation for Simulink model "HexaMotor_MotorTest".
 *
 * Simulink Coder version                : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 14:39:25 2024
 *
 * Note that the generated code is not dependent on this header file.
 * The file is used in cojuction with the automatic build procedure.
 * It is included by the sample main executable harness
 * MATLAB/rtw/c/src/common/rt_main.c.
 *
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "HexaMotor_MotorTest.h"
#endif                                 /* RTW_HEADER_rtmodel_h_ */
