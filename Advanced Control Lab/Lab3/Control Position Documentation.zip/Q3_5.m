% Define transfer function parameters
s = tf('s'); 
G = 2.42 / (0.06 * s + 1) / s; % Example transfer function (adjust as needed)

% Simulate response using identified transfer function
[y_sim, t_sim] = lsim(G / (1 + G), ScopeData.signals.values(:, 1), ScopeData.time);

% Calculate damping ratio (ξ) and other characteristics
[peak_value, peak_index] = max(y_sim);
peak_time = t_sim(peak_index);

y_ss = y_sim(end); % Steady-state value
overshoot = ((peak_value - y_ss) / y_ss) * 100;
xi = -log(overshoot / 100) / sqrt(pi^2 + log(overshoot / 100)^2);

% Plotting
figure;
plot(ScopeData.time, ScopeData.signals.values(:, 1), 'b', 'LineWidth', 1.5); % Step input
hold on;
plot(ScopeData.time, ScopeData.signals.values(:, 2), 'r', 'MarkerSize', 15); % Recorded output
plot(t_sim, y_sim, 'k', 'LineWidth', 2); % Simulated output

% Mark peak time and overshoot for simulated response
plot(peak_time, peak_value, 'ko', 'MarkerSize', 10); % Peak time marker
text(peak_time, peak_value, sprintf('  Peak\n  %.2f s\n  Overshoot: %.2f%%', peak_time, overshoot), ...
    'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left', 'Color', 'k');

hold off;

% Customize plot
xlabel('Time (s)');
ylabel('Response');
title('Step Response Comparison');
legend('Step Input', 'Recorded Output', 'Simulated Output');
grid on;
