/*
 * HexaMotor_Position_Control.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HexaMotor_Position_Control".
 *
 * Model version              : 6.80
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 16:46:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HexaMotor_Position_Control_h_
#define RTW_HEADER_HexaMotor_Position_Control_h_
#ifndef HexaMotor_Position_Control_COMMON_INCLUDES_
#define HexaMotor_Position_Control_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "ext_mode.h"
#include "MW_I2C.h"
#include "MW_PWM.h"
#include "MW_arduino_digitalio.h"
#endif                         /* HexaMotor_Position_Control_COMMON_INCLUDES_ */

#include "HexaMotor_Position_Control_types.h"
#include "rtGetInf.h"
#include <string.h>
#include "rt_nonfinite.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T rads[2];                      /* '<S4>/Gain1' */
  real_T ManualSwitch;                 /* '<Root>/Manual Switch' */
  real_T TmpSignalConversionAtTAQSigLogg[2];
  /* '<Root>/TmpSignal ConversionAtTAQSigLogging_InsertedFor_Mux2_at_outport_0Inport1' */
  real_T Clock;                        /* '<S5>/Clock' */
  real_T Diff;                         /* '<S62>/Diff' */
} B_HexaMotor_Position_Control_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  motorcarrier_blocks_mkrmotorc_T obj; /* '<Root>/Encoder 1' */
  codertarget_arduinobase_block_T obj_n;/* '<S5>/Digital Output' */
  codertarget_arduinobase_inter_T obj_i;/* '<S3>/Reverse PWM' */
  codertarget_arduinobase_inter_T obj_g;/* '<S3>/Forward PWM' */
  real_T Filter_DSTATE;                /* '<S32>/Filter' */
  real_T UD_DSTATE;                    /* '<S62>/UD' */
  struct {
    void *LoggedData;
  } rad_PWORK;                         /* '<Root>/rad' */

  int32_T clockTickCounter;            /* '<Root>/Discrete Pulse Generator' */
  boolean_T Delay_DSTATE;              /* '<S5>/Delay' */
} DW_HexaMotor_Position_Control_T;

/* Parameters (default storage) */
struct P_HexaMotor_Position_Control_T_ {
  real_T sampleRate;                   /* Variable: sampleRate
                                        * Referenced by: '<Root>/Discrete Pulse Generator'
                                        */
  real_T DiscretePIDController_D;     /* Mask Parameter: DiscretePIDController_D
                                       * Referenced by: '<S31>/Derivative Gain'
                                       */
  real_T Difference_ICPrevInput;       /* Mask Parameter: Difference_ICPrevInput
                                        * Referenced by: '<S62>/UD'
                                        */
  real_T DiscretePIDController_InitialCo;
                              /* Mask Parameter: DiscretePIDController_InitialCo
                               * Referenced by: '<S32>/Filter'
                               */
  real_T DiscretePIDController_N;     /* Mask Parameter: DiscretePIDController_N
                                       * Referenced by: '<S40>/Filter Coefficient'
                                       */
  real_T DiscretePIDController_P;     /* Mask Parameter: DiscretePIDController_P
                                       * Referenced by: '<S42>/Proportional Gain'
                                       */
  real_T ChirpSignal_T;                /* Mask Parameter: ChirpSignal_T
                                        * Referenced by: '<S1>/targetTime'
                                        */
  real_T ChirpSignal_f1;               /* Mask Parameter: ChirpSignal_f1
                                        * Referenced by:
                                        *   '<S1>/deltaFreq'
                                        *   '<S1>/initialFreq'
                                        */
  real_T ChirpSignal_f2;               /* Mask Parameter: ChirpSignal_f2
                                        * Referenced by: '<S1>/deltaFreq'
                                        */
  real_T PPR_1_Gain;                   /* Expression: 1/48
                                        * Referenced by: '<S4>/PPR_1'
                                        */
  real_T Gear_Gain;                    /* Expression: 1/20.4
                                        * Referenced by: '<S4>/Gear'
                                        */
  real_T Gain1_Gain;                   /* Expression: 2*pi
                                        * Referenced by: '<S4>/Gain1'
                                        */
  real_T DiscretePulseGenerator_Amp;   /* Expression: 1
                                        * Referenced by: '<Root>/Discrete Pulse Generator'
                                        */
  real_T DiscretePulseGenerator_PhaseDel;/* Expression: 1/sampleRate
                                          * Referenced by: '<Root>/Discrete Pulse Generator'
                                          */
  real_T Gain_Gain;                    /* Expression: 0.5
                                        * Referenced by: '<S1>/Gain'
                                        */
  real_T Filter_gainval;               /* Computed Parameter: Filter_gainval
                                        * Referenced by: '<S32>/Filter'
                                        */
  real_T Constant2_Value;              /* Expression: 0.52
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: -0.52
                                        * Referenced by: '<Root>/Constant3'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<Root>/Switch'
                                        */
  real_T Gain2_Gain;                   /* Expression: 255/12
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S5>/Constant1'
                                        */
  int16_T Constant1_Value_b;           /* Computed Parameter: Constant1_Value_b
                                        * Referenced by: '<S3>/Constant1'
                                        */
  int16_T Switch_Threshold_e;          /* Computed Parameter: Switch_Threshold_e
                                        * Referenced by: '<S3>/Switch'
                                        */
  boolean_T Delay_InitialCondition;/* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S5>/Delay'
                                    */
  uint8_T ManualSwitch_CurrentSetting;
                              /* Computed Parameter: ManualSwitch_CurrentSetting
                               * Referenced by: '<Root>/Manual Switch'
                               */
};

/* Real-time Model Data Structure */
struct tag_RTM_HexaMotor_Position_Co_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_HexaMotor_Position_Control_T HexaMotor_Position_Control_P;

/* Block signals (default storage) */
extern B_HexaMotor_Position_Control_T HexaMotor_Position_Control_B;

/* Block states (default storage) */
extern DW_HexaMotor_Position_Control_T HexaMotor_Position_Control_DW;

/* Model entry point functions */
extern void HexaMotor_Position_Control_initialize(void);
extern void HexaMotor_Position_Control_step(void);
extern void HexaMotor_Position_Control_terminate(void);

/* Real-time Model object */
extern RT_MODEL_HexaMotor_Position_C_T *const HexaMotor_Position_Control_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S54>/1//T' : Unused code path elimination
 * Block '<S55>/Avoid Divide by Zero' : Unused code path elimination
 * Block '<S58>/Compare' : Unused code path elimination
 * Block '<S58>/Constant' : Unused code path elimination
 * Block '<S59>/Compare' : Unused code path elimination
 * Block '<S59>/Constant' : Unused code path elimination
 * Block '<S55>/Constant' : Unused code path elimination
 * Block '<S55>/Logical Operator' : Unused code path elimination
 * Block '<S55>/Max' : Unused code path elimination
 * Block '<S55>/Probe' : Unused code path elimination
 * Block '<S55>/Sum1' : Unused code path elimination
 * Block '<S55>/Time constant' : Unused code path elimination
 * Block '<S61>/Integrator' : Unused code path elimination
 * Block '<S61>/Saturation' : Unused code path elimination
 * Block '<S54>/K' : Unused code path elimination
 * Block '<S54>/Sum1' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HexaMotor_Position_Control'
 * '<S1>'   : 'HexaMotor_Position_Control/Chirp Signal'
 * '<S2>'   : 'HexaMotor_Position_Control/Discrete PID Controller'
 * '<S3>'   : 'HexaMotor_Position_Control/M3 M4 DC Motors'
 * '<S4>'   : 'HexaMotor_Position_Control/Subsystem'
 * '<S5>'   : 'HexaMotor_Position_Control/System SampleRate Test'
 * '<S6>'   : 'HexaMotor_Position_Control/Discrete PID Controller/Anti-windup'
 * '<S7>'   : 'HexaMotor_Position_Control/Discrete PID Controller/D Gain'
 * '<S8>'   : 'HexaMotor_Position_Control/Discrete PID Controller/Filter'
 * '<S9>'   : 'HexaMotor_Position_Control/Discrete PID Controller/Filter ICs'
 * '<S10>'  : 'HexaMotor_Position_Control/Discrete PID Controller/I Gain'
 * '<S11>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Ideal P Gain'
 * '<S12>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Ideal P Gain Fdbk'
 * '<S13>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Integrator'
 * '<S14>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Integrator ICs'
 * '<S15>'  : 'HexaMotor_Position_Control/Discrete PID Controller/N Copy'
 * '<S16>'  : 'HexaMotor_Position_Control/Discrete PID Controller/N Gain'
 * '<S17>'  : 'HexaMotor_Position_Control/Discrete PID Controller/P Copy'
 * '<S18>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Parallel P Gain'
 * '<S19>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Reset Signal'
 * '<S20>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Saturation'
 * '<S21>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Saturation Fdbk'
 * '<S22>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Sum'
 * '<S23>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Sum Fdbk'
 * '<S24>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tracking Mode'
 * '<S25>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tracking Mode Sum'
 * '<S26>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tsamp - Integral'
 * '<S27>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tsamp - Ngain'
 * '<S28>'  : 'HexaMotor_Position_Control/Discrete PID Controller/postSat Signal'
 * '<S29>'  : 'HexaMotor_Position_Control/Discrete PID Controller/preSat Signal'
 * '<S30>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Anti-windup/Disabled'
 * '<S31>'  : 'HexaMotor_Position_Control/Discrete PID Controller/D Gain/Internal Parameters'
 * '<S32>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Filter/Disc. Forward Euler Filter'
 * '<S33>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Filter ICs/Internal IC - Filter'
 * '<S34>'  : 'HexaMotor_Position_Control/Discrete PID Controller/I Gain/Disabled'
 * '<S35>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Ideal P Gain/Passthrough'
 * '<S36>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S37>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Integrator/Disabled'
 * '<S38>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Integrator ICs/Disabled'
 * '<S39>'  : 'HexaMotor_Position_Control/Discrete PID Controller/N Copy/Disabled'
 * '<S40>'  : 'HexaMotor_Position_Control/Discrete PID Controller/N Gain/Internal Parameters'
 * '<S41>'  : 'HexaMotor_Position_Control/Discrete PID Controller/P Copy/Disabled'
 * '<S42>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Parallel P Gain/Internal Parameters'
 * '<S43>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Reset Signal/Disabled'
 * '<S44>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Saturation/Passthrough'
 * '<S45>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Saturation Fdbk/Disabled'
 * '<S46>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Sum/Sum_PD'
 * '<S47>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Sum Fdbk/Disabled'
 * '<S48>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tracking Mode/Disabled'
 * '<S49>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tracking Mode Sum/Passthrough'
 * '<S50>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tsamp - Integral/Disabled wSignal Specification'
 * '<S51>'  : 'HexaMotor_Position_Control/Discrete PID Controller/Tsamp - Ngain/Passthrough'
 * '<S52>'  : 'HexaMotor_Position_Control/Discrete PID Controller/postSat Signal/Forward_Path'
 * '<S53>'  : 'HexaMotor_Position_Control/Discrete PID Controller/preSat Signal/Forward_Path'
 * '<S54>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)'
 * '<S55>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant'
 * '<S56>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Initialization'
 * '<S57>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Integrator (Discrete or Continuous)'
 * '<S58>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant/Compare To Constant'
 * '<S59>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Enable//disable time constant/Compare To Zero'
 * '<S60>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Initialization/Init_u'
 * '<S61>'  : 'HexaMotor_Position_Control/Subsystem/Low-Pass Filter (Discrete or Continuous)/Integrator (Discrete or Continuous)/Discrete'
 * '<S62>'  : 'HexaMotor_Position_Control/System SampleRate Test/Difference'
 */
#endif                            /* RTW_HEADER_HexaMotor_Position_Control_h_ */
