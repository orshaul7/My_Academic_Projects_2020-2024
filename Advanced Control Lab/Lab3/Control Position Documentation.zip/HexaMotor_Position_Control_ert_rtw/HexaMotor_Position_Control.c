/*
 * HexaMotor_Position_Control.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HexaMotor_Position_Control".
 *
 * Model version              : 6.80
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 16:46:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "HexaMotor_Position_Control.h"
#include "HexaMotor_Position_Control_types.h"
#include <string.h>
#include <math.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include <stddef.h>
#include "HexaMotor_Position_Control_private.h"

/* Block signals (default storage) */
B_HexaMotor_Position_Control_T HexaMotor_Position_Control_B;

/* Block states (default storage) */
DW_HexaMotor_Position_Control_T HexaMotor_Position_Control_DW;

/* Real-time model */
static RT_MODEL_HexaMotor_Position_C_T HexaMotor_Position_Control_M_;
RT_MODEL_HexaMotor_Position_C_T *const HexaMotor_Position_Control_M =
  &HexaMotor_Position_Control_M_;

/* Forward declaration for local functions */
static void HexaMotor_Posi_SystemCore_setup(motorcarrier_blocks_mkrmotorc_T *obj);
void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Hi;
  uint32_T in0Lo;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~(uint32_T)in0 + 1U : (uint32_T)in0;
  absIn1 = in1 < 0 ? ~(uint32_T)in1 + 1U : (uint32_T)in1;
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << /*MW:OvBitwiseOk*/ 16U) + /*MW:OvCarryOk*/ absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += /*MW:OvCarryOk*/ productHiLo << /*MW:OvBitwiseOk*/ 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if ((in0 != 0) && ((in1 != 0) && ((in0 > 0) != (in1 > 0)))) {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

int32_T mul_s32_sat(int32_T a, int32_T b)
{
  int32_T result;
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  if (((int32_T)u32_chi > 0) || ((u32_chi == 0U) && (u32_clo >= 2147483648U))) {
    result = MAX_int32_T;
  } else if (((int32_T)u32_chi < -1) || (((int32_T)u32_chi == -1) && (u32_clo <
               2147483648U))) {
    result = MIN_int32_T;
  } else {
    result = (int32_T)u32_clo;
  }

  return result;
}

static void HexaMotor_Posi_SystemCore_setup(motorcarrier_blocks_mkrmotorc_T *obj)
{
  MW_I2C_Mode_Type modename;
  uint32_T i2cname;
  f_codertarget_arduinobase_int_T *obj_0;
  int32_T x;
  uint32_T varargin_1;
  uint8_T SwappedDataBytes[6];
  uint8_T final_data_to_write[6];
  uint8_T data_uint8[4];
  obj->isSetupComplete = false;
  obj->isInitialized = 1;
  obj_0 = &obj->i2cObj;
  modename = MW_I2C_MASTER;
  i2cname = 0;
  obj->i2cObj.I2CDriverObj.MW_I2C_HANDLE = MW_I2C_Open(i2cname, modename);
  obj->i2cObj.BusSpeed = 100000U;
  varargin_1 = obj->i2cObj.BusSpeed;
  MW_I2C_SetBusSpeed(obj_0->I2CDriverObj.MW_I2C_HANDLE, varargin_1);
  x = 0;
  memcpy((void *)&data_uint8[0], (void *)&x, (size_t)4 * sizeof(uint8_T));
  final_data_to_write[0] = 8U;
  final_data_to_write[1] = 0U;
  final_data_to_write[2] = data_uint8[0];
  final_data_to_write[3] = data_uint8[1];
  final_data_to_write[4] = data_uint8[2];
  final_data_to_write[5] = data_uint8[3];
  memcpy((void *)&SwappedDataBytes[0], (void *)&final_data_to_write[0], (size_t)
         6 * sizeof(uint8_T));
  MW_I2C_MasterWrite(obj->i2cObj.I2CDriverObj.MW_I2C_HANDLE, 102U,
                     &SwappedDataBytes[0], 6U, false, false);
  obj->isSetupComplete = true;
}

/* Model step function */
void HexaMotor_Position_Control_step(void)
{
  /* local block i/o variables */
  real_T rtb_FilterCoefficient;
  codertarget_arduinobase_inter_T *obj_0;
  f_codertarget_arduinobase_int_T *obj;
  real_T Sum;
  int32_T a;
  int32_T count;
  int16_T rtb_DataTypeConversion;
  int16_T rtb_Switch_idx_0;
  uint8_T out_raw[5];
  uint8_T output_raw[5];
  uint8_T SwappedDataBytes[2];
  uint8_T final_data_to_write[2];

  /* MATLABSystem: '<Root>/Encoder 1' */
  final_data_to_write[0] = 7U;
  final_data_to_write[1] = 0U;
  obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
  memcpy((void *)&SwappedDataBytes[0], (void *)&final_data_to_write[0], (size_t)
         2 * sizeof(uint8_T));
  MW_I2C_MasterWrite(obj->I2CDriverObj.MW_I2C_HANDLE, 102U, &SwappedDataBytes[0],
                     2U, false, false);
  obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
  MW_I2C_MasterRead(obj->I2CDriverObj.MW_I2C_HANDLE, 102U, &output_raw[0], 5U,
                    false, false);
  memcpy((void *)&out_raw[0], (void *)&output_raw[0], (size_t)5 * sizeof(uint8_T));
  memcpy((void *)&count, (void *)&out_raw[1], (size_t)1 * sizeof(int32_T));
  final_data_to_write[0] = 10U;
  final_data_to_write[1] = 0U;
  obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
  memcpy((void *)&SwappedDataBytes[0], (void *)&final_data_to_write[0], (size_t)
         2 * sizeof(uint8_T));
  MW_I2C_MasterWrite(obj->I2CDriverObj.MW_I2C_HANDLE, 102U, &SwappedDataBytes[0],
                     2U, false, false);
  obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
  MW_I2C_MasterRead(obj->I2CDriverObj.MW_I2C_HANDLE, 102U, &output_raw[0], 5U,
                    false, false);
  memcpy((void *)&out_raw[0], (void *)&output_raw[0], (size_t)5 * sizeof(uint8_T));
  memcpy((void *)&a, (void *)&out_raw[1], (size_t)1 * sizeof(int32_T));

  /* Gain: '<S4>/Gain1' incorporates:
   *  DataTypeConversion: '<S4>/Data Type Conversion1'
   *  Gain: '<S4>/Gear'
   *  Gain: '<S4>/PPR_1'
   *  MATLABSystem: '<Root>/Encoder 1'
   */
  HexaMotor_Position_Control_B.rads[0] = HexaMotor_Position_Control_P.PPR_1_Gain
    * (real_T)count * HexaMotor_Position_Control_P.Gear_Gain *
    HexaMotor_Position_Control_P.Gain1_Gain;
  HexaMotor_Position_Control_B.rads[1] = HexaMotor_Position_Control_P.PPR_1_Gain
    * (real_T)mul_s32_sat(a, 100) * HexaMotor_Position_Control_P.Gear_Gain *
    HexaMotor_Position_Control_P.Gain1_Gain;

  /* DiscretePulseGenerator: '<Root>/Discrete Pulse Generator' */
  HexaMotor_Position_Control_B.ManualSwitch =
    (HexaMotor_Position_Control_DW.clockTickCounter < 2.0 /
     HexaMotor_Position_Control_P.sampleRate) &&
    (HexaMotor_Position_Control_DW.clockTickCounter >= 0) ?
    HexaMotor_Position_Control_P.DiscretePulseGenerator_Amp : 0.0;

  /* DiscretePulseGenerator: '<Root>/Discrete Pulse Generator' */
  if (HexaMotor_Position_Control_DW.clockTickCounter >= 4.0 /
      HexaMotor_Position_Control_P.sampleRate - 1.0) {
    HexaMotor_Position_Control_DW.clockTickCounter = 0;
  } else {
    HexaMotor_Position_Control_DW.clockTickCounter++;
  }

  /* Clock: '<S1>/Clock1' incorporates:
   *  Clock: '<S5>/Clock'
   */
  HexaMotor_Position_Control_B.Clock = HexaMotor_Position_Control_M->Timing.t[0];

  /* ManualSwitch: '<Root>/Manual Switch' */
  if (HexaMotor_Position_Control_P.ManualSwitch_CurrentSetting != 1) {
    /* ManualSwitch: '<Root>/Manual Switch' incorporates:
     *  Clock: '<S1>/Clock1'
     *  Constant: '<S1>/deltaFreq'
     *  Constant: '<S1>/initialFreq'
     *  Constant: '<S1>/targetTime'
     *  Gain: '<S1>/Gain'
     *  Product: '<S1>/Product'
     *  Product: '<S1>/Product1'
     *  Product: '<S1>/Product2'
     *  Sum: '<S1>/Sum'
     *  Trigonometry: '<S1>/Output'
     */
    HexaMotor_Position_Control_B.ManualSwitch = sin
      (((HexaMotor_Position_Control_P.ChirpSignal_f2 -
         HexaMotor_Position_Control_P.ChirpSignal_f1) * 6.2831853071795862 /
        HexaMotor_Position_Control_P.ChirpSignal_T
        * HexaMotor_Position_Control_P.Gain_Gain *
        HexaMotor_Position_Control_B.Clock + 6.2831853071795862 *
        HexaMotor_Position_Control_P.ChirpSignal_f1) *
       HexaMotor_Position_Control_B.Clock);
  }

  /* End of ManualSwitch: '<Root>/Manual Switch' */

  /* SignalConversion generated from: '<Root>/Mux2' */
  HexaMotor_Position_Control_B.TmpSignalConversionAtTAQSigLogg[0] =
    HexaMotor_Position_Control_B.ManualSwitch;
  HexaMotor_Position_Control_B.TmpSignalConversionAtTAQSigLogg[1] =
    HexaMotor_Position_Control_B.rads[0];

  /* Sum: '<Root>/Sum' */
  Sum = HexaMotor_Position_Control_B.ManualSwitch -
    HexaMotor_Position_Control_B.rads[0];

  /* Gain: '<S40>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S32>/Filter'
   *  Gain: '<S31>/Derivative Gain'
   *  Sum: '<S32>/SumD'
   */
  rtb_FilterCoefficient = (HexaMotor_Position_Control_P.DiscretePIDController_D *
    Sum - HexaMotor_Position_Control_DW.Filter_DSTATE) *
    HexaMotor_Position_Control_P.DiscretePIDController_N;

  /* Sum: '<S46>/Sum' incorporates:
   *  Gain: '<S42>/Proportional Gain'
   */
  Sum = HexaMotor_Position_Control_P.DiscretePIDController_P * Sum +
    rtb_FilterCoefficient;

  /* Switch: '<Root>/Switch' incorporates:
   *  Constant: '<Root>/Constant2'
   *  Constant: '<Root>/Constant3'
   *  Sum: '<Root>/Add'
   *  Sum: '<Root>/Add1'
   */
  if (Sum > HexaMotor_Position_Control_P.Switch_Threshold) {
    Sum += HexaMotor_Position_Control_P.Constant2_Value;
  } else {
    Sum += HexaMotor_Position_Control_P.Constant3_Value;
  }

  /* DataTypeConversion: '<S3>/Data Type Conversion' incorporates:
   *  Gain: '<Root>/Gain2'
   *  Switch: '<Root>/Switch'
   */
  Sum = floor(HexaMotor_Position_Control_P.Gain2_Gain * Sum);
  if (rtIsNaN(Sum) || rtIsInf(Sum)) {
    Sum = 0.0;
  } else {
    Sum = fmod(Sum, 65536.0);
  }

  rtb_DataTypeConversion = (int16_T)(Sum < 0.0 ? (int32_T)(int16_T)-(int16_T)
    (uint16_T)-Sum : (int32_T)(int16_T)(uint16_T)Sum);

  /* End of DataTypeConversion: '<S3>/Data Type Conversion' */

  /* Switch: '<S3>/Switch' incorporates:
   *  Constant: '<S3>/Constant1'
   */
  if (rtb_DataTypeConversion > HexaMotor_Position_Control_P.Switch_Threshold_e)
  {
    rtb_Switch_idx_0 = rtb_DataTypeConversion;
    rtb_DataTypeConversion = HexaMotor_Position_Control_P.Constant1_Value_b;
  } else {
    rtb_Switch_idx_0 = HexaMotor_Position_Control_P.Constant1_Value_b;

    /* Abs: '<S3>/Abs' incorporates:
     *  Constant: '<S3>/Constant1'
     */
    if (rtb_DataTypeConversion < 0) {
      rtb_DataTypeConversion = (int16_T)-rtb_DataTypeConversion;
    }

    /* End of Abs: '<S3>/Abs' */
  }

  /* End of Switch: '<S3>/Switch' */

  /* MATLABSystem: '<S3>/Forward PWM' */
  obj_0 = &HexaMotor_Position_Control_DW.obj_g;
  obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(3U);
  if (rtb_Switch_idx_0 <= 255.0) {
    Sum = rtb_Switch_idx_0;
  } else {
    Sum = 255.0;
  }

  if (!(Sum >= 0.0)) {
    Sum = 0.0;
  }

  MW_PWM_SetDutyCycle
    (HexaMotor_Position_Control_DW.obj_g.PWMDriverObj.MW_PWM_HANDLE, Sum);

  /* End of MATLABSystem: '<S3>/Forward PWM' */

  /* MATLABSystem: '<S3>/Reverse PWM' */
  obj_0 = &HexaMotor_Position_Control_DW.obj_i;
  obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(2U);
  if (rtb_DataTypeConversion <= 255.0) {
    Sum = rtb_DataTypeConversion;
  } else {
    Sum = 255.0;
  }

  if (!(Sum >= 0.0)) {
    Sum = 0.0;
  }

  MW_PWM_SetDutyCycle
    (HexaMotor_Position_Control_DW.obj_i.PWMDriverObj.MW_PWM_HANDLE, Sum);

  /* End of MATLABSystem: '<S3>/Reverse PWM' */
  /* Sum: '<S62>/Diff' incorporates:
   *  UnitDelay: '<S62>/UD'
   */
  HexaMotor_Position_Control_B.Diff = HexaMotor_Position_Control_B.Clock -
    HexaMotor_Position_Control_DW.UD_DSTATE;

  /* Logic: '<S5>/XOR' incorporates:
   *  Constant: '<S5>/Constant1'
   *  Delay: '<S5>/Delay'
   */
  HexaMotor_Position_Control_DW.Delay_DSTATE =
    (HexaMotor_Position_Control_P.Constant1_Value != 0.0) ^
    HexaMotor_Position_Control_DW.Delay_DSTATE;

  /* MATLABSystem: '<S5>/Digital Output' incorporates:
   *  Delay: '<S5>/Delay'
   */
  writeDigitalPin(0, (uint8_T)HexaMotor_Position_Control_DW.Delay_DSTATE);

  /* Update for DiscreteIntegrator: '<S32>/Filter' */
  HexaMotor_Position_Control_DW.Filter_DSTATE +=
    HexaMotor_Position_Control_P.Filter_gainval * rtb_FilterCoefficient;

  /* Update for UnitDelay: '<S62>/UD' */
  HexaMotor_Position_Control_DW.UD_DSTATE = HexaMotor_Position_Control_B.Clock;

  {                                    /* Sample time: [0.0s, 0.0s] */
    extmodeErrorCode_T errorCode = EXTMODE_SUCCESS;
    extmodeSimulationTime_T currentTime = (extmodeSimulationTime_T)
      HexaMotor_Position_Control_M->Timing.t[0];

    /* Trigger External Mode event */
    errorCode = extmodeEvent(0,currentTime);
    if (errorCode != EXTMODE_SUCCESS) {
      /* Code to handle External Mode event errors
         may be added here */
    }
  }

  {                                    /* Sample time: [0.005s, 0.0s] */
    extmodeErrorCode_T errorCode = EXTMODE_SUCCESS;
    extmodeSimulationTime_T currentTime = (extmodeSimulationTime_T)
      ((HexaMotor_Position_Control_M->Timing.clockTick1) * 0.005);

    /* Trigger External Mode event */
    errorCode = extmodeEvent(1,currentTime);
    if (errorCode != EXTMODE_SUCCESS) {
      /* Code to handle External Mode event errors
         may be added here */
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  HexaMotor_Position_Control_M->Timing.t[0] =
    ((time_T)(++HexaMotor_Position_Control_M->Timing.clockTick0)) *
    HexaMotor_Position_Control_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.005s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.005, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    HexaMotor_Position_Control_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void HexaMotor_Position_Control_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)HexaMotor_Position_Control_M, 0,
                sizeof(RT_MODEL_HexaMotor_Position_C_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&HexaMotor_Position_Control_M->solverInfo,
                          &HexaMotor_Position_Control_M->Timing.simTimeStep);
    rtsiSetTPtr(&HexaMotor_Position_Control_M->solverInfo, &rtmGetTPtr
                (HexaMotor_Position_Control_M));
    rtsiSetStepSizePtr(&HexaMotor_Position_Control_M->solverInfo,
                       &HexaMotor_Position_Control_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&HexaMotor_Position_Control_M->solverInfo,
                          (&rtmGetErrorStatus(HexaMotor_Position_Control_M)));
    rtsiSetRTModelPtr(&HexaMotor_Position_Control_M->solverInfo,
                      HexaMotor_Position_Control_M);
  }

  rtsiSetSimTimeStep(&HexaMotor_Position_Control_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&HexaMotor_Position_Control_M->solverInfo,
                    "FixedStepDiscrete");
  rtmSetTPtr(HexaMotor_Position_Control_M,
             &HexaMotor_Position_Control_M->Timing.tArray[0]);
  rtmSetTFinal(HexaMotor_Position_Control_M, 30.0);
  HexaMotor_Position_Control_M->Timing.stepSize0 = 0.005;

  /* External mode info */
  HexaMotor_Position_Control_M->Sizes.checksums[0] = (1102125056U);
  HexaMotor_Position_Control_M->Sizes.checksums[1] = (91971035U);
  HexaMotor_Position_Control_M->Sizes.checksums[2] = (1145163602U);
  HexaMotor_Position_Control_M->Sizes.checksums[3] = (3317537436U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[9];
    HexaMotor_Position_Control_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = &rtAlwaysEnabled;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(HexaMotor_Position_Control_M->extModeInfo,
      &HexaMotor_Position_Control_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(HexaMotor_Position_Control_M->extModeInfo,
                        HexaMotor_Position_Control_M->Sizes.checksums);
    rteiSetTPtr(HexaMotor_Position_Control_M->extModeInfo, rtmGetTPtr
                (HexaMotor_Position_Control_M));
  }

  /* block I/O */
  (void) memset(((void *) &HexaMotor_Position_Control_B), 0,
                sizeof(B_HexaMotor_Position_Control_T));

  /* states (dwork) */
  (void) memset((void *)&HexaMotor_Position_Control_DW, 0,
                sizeof(DW_HexaMotor_Position_Control_T));

  {
    codertarget_arduinobase_inter_T *obj_0;
    f_codertarget_arduinobase_int_T *obj;

    /* InitializeConditions for DiscretePulseGenerator: '<Root>/Discrete Pulse Generator' */
    HexaMotor_Position_Control_DW.clockTickCounter = -200;

    /* InitializeConditions for DiscreteIntegrator: '<S32>/Filter' */
    HexaMotor_Position_Control_DW.Filter_DSTATE =
      HexaMotor_Position_Control_P.DiscretePIDController_InitialCo;

    /* InitializeConditions for UnitDelay: '<S62>/UD' */
    HexaMotor_Position_Control_DW.UD_DSTATE =
      HexaMotor_Position_Control_P.Difference_ICPrevInput;

    /* InitializeConditions for Delay: '<S5>/Delay' */
    HexaMotor_Position_Control_DW.Delay_DSTATE =
      HexaMotor_Position_Control_P.Delay_InitialCondition;

    /* Start for MATLABSystem: '<Root>/Encoder 1' */
    HexaMotor_Position_Control_DW.obj.isInitialized = 0;
    obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
    HexaMotor_Position_Control_DW.obj.i2cObj.DefaultMaximumBusSpeedInHz =
      400000.0;
    HexaMotor_Position_Control_DW.obj.i2cObj.isInitialized = 0;
    obj->I2CDriverObj.MW_I2C_HANDLE = NULL;
    HexaMotor_Position_Control_DW.obj.i2cObj.matlabCodegenIsDeleted = false;
    HexaMotor_Position_Control_DW.obj.matlabCodegenIsDeleted = false;
    HexaMotor_Posi_SystemCore_setup(&HexaMotor_Position_Control_DW.obj);

    /* Start for MATLABSystem: '<S3>/Forward PWM' */
    HexaMotor_Position_Control_DW.obj_g.matlabCodegenIsDeleted = false;
    obj_0 = &HexaMotor_Position_Control_DW.obj_g;
    HexaMotor_Position_Control_DW.obj_g.isInitialized = 1;
    obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_Open(3U, 0.0, 0.0);
    HexaMotor_Position_Control_DW.obj_g.isSetupComplete = true;

    /* Start for MATLABSystem: '<S3>/Reverse PWM' */
    HexaMotor_Position_Control_DW.obj_i.matlabCodegenIsDeleted = false;
    obj_0 = &HexaMotor_Position_Control_DW.obj_i;
    HexaMotor_Position_Control_DW.obj_i.isInitialized = 1;
    obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_Open(2U, 0.0, 0.0);
    HexaMotor_Position_Control_DW.obj_i.isSetupComplete = true;

    /* Start for MATLABSystem: '<S5>/Digital Output' */
    HexaMotor_Position_Control_DW.obj_n.matlabCodegenIsDeleted = false;
    HexaMotor_Position_Control_DW.obj_n.isInitialized = 1;
    digitalIOSetup(0, 1);
    HexaMotor_Position_Control_DW.obj_n.isSetupComplete = true;
  }
}

/* Model terminate function */
void HexaMotor_Position_Control_terminate(void)
{
  codertarget_arduinobase_inter_T *obj_0;
  f_codertarget_arduinobase_int_T *obj;

  /* Terminate for MATLABSystem: '<Root>/Encoder 1' */
  if (!HexaMotor_Position_Control_DW.obj.matlabCodegenIsDeleted) {
    HexaMotor_Position_Control_DW.obj.matlabCodegenIsDeleted = true;
    if ((HexaMotor_Position_Control_DW.obj.isInitialized == 1) &&
        HexaMotor_Position_Control_DW.obj.isSetupComplete) {
      obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
      MW_I2C_Close(obj->I2CDriverObj.MW_I2C_HANDLE);
    }
  }

  obj = &HexaMotor_Position_Control_DW.obj.i2cObj;
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    if (obj->isInitialized == 1) {
      obj->isInitialized = 2;
    }
  }

  /* End of Terminate for MATLABSystem: '<Root>/Encoder 1' */
  /* Terminate for MATLABSystem: '<S3>/Forward PWM' */
  obj_0 = &HexaMotor_Position_Control_DW.obj_g;
  if (!HexaMotor_Position_Control_DW.obj_g.matlabCodegenIsDeleted) {
    HexaMotor_Position_Control_DW.obj_g.matlabCodegenIsDeleted = true;
    if ((HexaMotor_Position_Control_DW.obj_g.isInitialized == 1) &&
        HexaMotor_Position_Control_DW.obj_g.isSetupComplete) {
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(3U);
      MW_PWM_SetDutyCycle
        (HexaMotor_Position_Control_DW.obj_g.PWMDriverObj.MW_PWM_HANDLE, 0.0);
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(3U);
      MW_PWM_Close
        (HexaMotor_Position_Control_DW.obj_g.PWMDriverObj.MW_PWM_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S3>/Forward PWM' */

  /* Terminate for MATLABSystem: '<S3>/Reverse PWM' */
  obj_0 = &HexaMotor_Position_Control_DW.obj_i;
  if (!HexaMotor_Position_Control_DW.obj_i.matlabCodegenIsDeleted) {
    HexaMotor_Position_Control_DW.obj_i.matlabCodegenIsDeleted = true;
    if ((HexaMotor_Position_Control_DW.obj_i.isInitialized == 1) &&
        HexaMotor_Position_Control_DW.obj_i.isSetupComplete) {
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(2U);
      MW_PWM_SetDutyCycle
        (HexaMotor_Position_Control_DW.obj_i.PWMDriverObj.MW_PWM_HANDLE, 0.0);
      obj_0->PWMDriverObj.MW_PWM_HANDLE = MW_PWM_GetHandle(2U);
      MW_PWM_Close
        (HexaMotor_Position_Control_DW.obj_i.PWMDriverObj.MW_PWM_HANDLE);
    }
  }

  /* End of Terminate for MATLABSystem: '<S3>/Reverse PWM' */
  /* Terminate for MATLABSystem: '<S5>/Digital Output' */
  if (!HexaMotor_Position_Control_DW.obj_n.matlabCodegenIsDeleted) {
    HexaMotor_Position_Control_DW.obj_n.matlabCodegenIsDeleted = true;
  }

  /* End of Terminate for MATLABSystem: '<S5>/Digital Output' */
}
