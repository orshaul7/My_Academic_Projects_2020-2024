/*
 * HexaMotor_Position_Control_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HexaMotor_Position_Control".
 *
 * Model version              : 6.80
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Tue Jun 25 16:46:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "HexaMotor_Position_Control.h"

/* Block parameters (default storage) */
P_HexaMotor_Position_Control_T HexaMotor_Position_Control_P = {
  /* Variable: sampleRate
   * Referenced by: '<Root>/Discrete Pulse Generator'
   */
  0.005,

  /* Mask Parameter: DiscretePIDController_D
   * Referenced by: '<S31>/Derivative Gain'
   */
  0.232,

  /* Mask Parameter: Difference_ICPrevInput
   * Referenced by: '<S62>/UD'
   */
  0.0,

  /* Mask Parameter: DiscretePIDController_InitialCo
   * Referenced by: '<S32>/Filter'
   */
  0.0,

  /* Mask Parameter: DiscretePIDController_N
   * Referenced by: '<S40>/Filter Coefficient'
   */
  100.0,

  /* Mask Parameter: DiscretePIDController_P
   * Referenced by: '<S42>/Proportional Gain'
   */
  12.36,

  /* Mask Parameter: ChirpSignal_T
   * Referenced by: '<S1>/targetTime'
   */
  30.0,

  /* Mask Parameter: ChirpSignal_f1
   * Referenced by:
   *   '<S1>/deltaFreq'
   *   '<S1>/initialFreq'
   */
  0.1,

  /* Mask Parameter: ChirpSignal_f2
   * Referenced by: '<S1>/deltaFreq'
   */
  5.0,

  /* Expression: 1/48
   * Referenced by: '<S4>/PPR_1'
   */
  0.020833333333333332,

  /* Expression: 1/20.4
   * Referenced by: '<S4>/Gear'
   */
  0.049019607843137261,

  /* Expression: 2*pi
   * Referenced by: '<S4>/Gain1'
   */
  6.2831853071795862,

  /* Expression: 1
   * Referenced by: '<Root>/Discrete Pulse Generator'
   */
  1.0,

  /* Expression: 1/sampleRate
   * Referenced by: '<Root>/Discrete Pulse Generator'
   */
  200.0,

  /* Expression: 0.5
   * Referenced by: '<S1>/Gain'
   */
  0.5,

  /* Computed Parameter: Filter_gainval
   * Referenced by: '<S32>/Filter'
   */
  0.005,

  /* Expression: 0.52
   * Referenced by: '<Root>/Constant2'
   */
  0.52,

  /* Expression: -0.52
   * Referenced by: '<Root>/Constant3'
   */
  -0.52,

  /* Expression: 0
   * Referenced by: '<Root>/Switch'
   */
  0.0,

  /* Expression: 255/12
   * Referenced by: '<Root>/Gain2'
   */
  21.25,

  /* Expression: 1
   * Referenced by: '<S5>/Constant1'
   */
  1.0,

  /* Computed Parameter: Constant1_Value_b
   * Referenced by: '<S3>/Constant1'
   */
  0,

  /* Computed Parameter: Switch_Threshold_e
   * Referenced by: '<S3>/Switch'
   */
  0,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S5>/Delay'
   */
  false,

  /* Computed Parameter: ManualSwitch_CurrentSetting
   * Referenced by: '<Root>/Manual Switch'
   */
  1U
};
