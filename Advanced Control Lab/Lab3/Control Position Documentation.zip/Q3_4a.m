% Define the theoretical transfer function
s = tf('s');
T_theoretical = 325.2 / (s^2 + 14.15*s + 351.4);

% Load your data (assuming 'ScopeData' is already in the workspace)
% Create iddata object
data = iddata(ScopeData.signals.values(:,2), ScopeData.signals.values(:,1), 0.005);

% Estimate the transfer function
T_estimated = tfest(data, 2, 0);

% Display the estimated transfer function
disp('Estimated Transfer Function:');
disp(T_estimated);

% Simulate the response of the theoretical transfer function
[y_theoretical, t_theoretical] = lsim(T_theoretical, ScopeData.signals.values(:,1), ScopeData.time);

% Plot the input data, recorded data, and theoretical response
figure;
plot(ScopeData.time, ScopeData.signals.values(:,1), 'm', 'LineWidth', 1.5); % Input data
hold on;
plot(ScopeData.time, ScopeData.signals.values(:,2), 'b', 'LineWidth', 1.5); % Recorded data
plot(t_theoretical, y_theoretical, 'g-.', 'LineWidth', 1.5); % Theoretical response
grid on;
title('Response Comparison');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Input Data', 'Recorded Data', 'Theoretical Response');
hold off;